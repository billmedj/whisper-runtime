# Authorized native soak — local handoff

This note concerns the existing, user-authorized four-hour Modal workload. It
does not authorize another paid attempt, another app, changed hardware/profile,
new input data, or a larger budget. The root agent confirmed the app stopped;
this audit made no remote calls, started no process on Modal, and changed none of
the 50 uploaded or three review-only files.

## Final outcome: stopped at the smoke memory gate

The actual GPU attempt failed at the registered `memory_gate` after smoke.
No hour-one phase started and no four-hour qualification was obtained. The root
later confirmed zero active tasks and Modal's reported `stopped_at` timestamp
2026-09-07 02:52:50 UTC (10:52:50 +08). The query time is unavailable; this local
audit made no additional remote status request.

Independent replay through `CommittedTranscript` validates all 30 retained
events: four provisional, 21 replacement, four commit and one FINAL. The exact
revision chain covers 744,800 samples (46.55 seconds), with three nonempty
captions. Terminal receipts report 47.103489543 seconds after `owner.factory`
(excluding model initialization/build), 2,328 chunks, 25 native
decodes and restored capacity/cleanup. Word edits were independently recomputed
as 7/114 (6.14035%, within the registered 10% smoke-quality gate).

Nevertheless, process RSS was 5,292,425,216 bytes, above the fixed
3,758,096,384-byte (3.5 GiB) ceiling. CUDA allocated/peak allocated/reserved bytes
were 160,720,896 / 290,099,200 / 358,612,992 respectively. These are different
accounting measures, not interchangeable totals. The post-smoke baseline was
never established, so this observation cannot identify a leak or the memory's
mapping origin. Do not raise the gate or classify smoke as successful.

The 13,968-byte raw event receipt remains `partial: true`, despite its valid
FINAL. Event SHA-256 is
`fd72348837988e1ff7d8e8d9585a3bb14cbec99a0061ccb750c56e88eb432968`.
The final attempt digest binds the failed overall result. See
`smoke-failure-local-audit.json` and `audit_smoke_failure.py`; the earlier local
candidate checks remain historical and were not rewritten.

## Approval scope and concluded run

- One ephemeral T4 worker, two CPU cores, 4,096 MiB memory, maximum one GPU
  container; no persistent deployment or application retry.
- `conservative-v1`, a gated 46.55-second smoke followed by four separately
  bounded one-hour source-paced native-SDK phases using the registered repeated
  speech/noise/silence recipe. This is not WebSocket, physical microphone or
  diverse four-hour speech qualification.
- Outer deadline: 14,800 seconds. Preregistered planning compute estimate:
  USD 5.156172, excluding build/startup/storage/egress/taxes/provider crash
  rescheduling; not a physical spending cap.
- App: `ap-pABNi973B2Un3GiEhrHvNB`.
- Client execution session: `24278` (provided by the root agent).
- Local journal records app start at `2026-09-07T02:51:45.790314+00:00`.
  App start is not completion or qualification; this handoff does not report a
  a new remote task count or infer that the endurance phases have passed.

## Initial failure and minimal correction

The preceding `release-soak-20260907-frozen-v2` attempt ended locally with
`InvalidError` after 81.864 ms. Its journal has no `app-started` event. The
preserved failure was caused by Modal 1.5.5 rejecting `retries=0` for a generator
during resource definition, before `app.run`.

The source diff is limited to removing that unsupported keyword and exposing
`sdk_retry_policy: null` / `generator_retries_supported: false` in budget metadata.
The intended application retry count remains zero. Review-only documentation
and the resource-definition regression were updated. No runtime module, input,
profile, phase schedule, bound or numerical policy changed.

The implementation agent reports 15 focused tests passing with the actual
pinned Modal 1.5.5 SDK. The added regression was inspected: it forbids `App.run`,
`App.deploy`, volume/function hydration, `Function.remote_gen`, and socket
connections while exercising real SDK resource definitions. In an environment
without the SDK that test is explicitly skipped; it is not evidence of a GPU
run. No such test was rerun by this audit.

## Independent source audit

`audit_approved_source.py` uses only local standard-library file/archive reads.
`approved-source-local-audit.json` and `harness-sdkfix.diff` retain its results:

- All 50 upload records and three review-only records match both the approved
  archive and current source bytes, including size and SHA-256.
- The archive has exactly 54 entries: those 53 files plus the byte-identical
  preflight JSON. No duplicate or extra entries were accepted.
- Upload bytes: 1,035,453. All 32 runtime module hashes match the earlier
  installed candidate/CPU smoke receipt.
- Only `infra/modal_release_soak.py` changed among uploaded paths. Review-only
  changes are the soak plan and `tools/test_modal_release_soak.py`.
- Registered input/profile/phases are unchanged. Budget fields are unchanged
  apart from the explicit SDK capability disclosure above.

Archive SHA-256:
`6e483b402ef8bc63e48d819a4f110f2e77bc2e5bf20d614b5fffb30214db0fad`

Preflight SHA-256:
`d158f29c1bb96e625f2b1d96cff7c7baa11374dd46098533e72f0dca7473edae`

Upload manifest digest:
`f7bd54cbec2c5c1ed4374fae576c55b75e2b911d87c12753e2d9d308f9175629`

Review-only manifest digest:
`8906d416c9ed6591d2c21fb8a26153ae8ba9675b4b3be520054b1250a97ae5a3`

The existing final candidate archives predate this SDK-only harness correction;
their 32 runtime modules remain applicable, but their old harness is not the
currently approved runner. Preserve both snapshots and failed-attempt evidence.
If the current attempt fails or further scope changes are needed, do not launch
another paid attempt without new user authority.
