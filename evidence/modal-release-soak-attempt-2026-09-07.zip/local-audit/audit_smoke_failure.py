"""Replay retained smoke events locally without inference or remote calls."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / "src"))

from whisper_runtime.adapters import StreamEventKind, TranscriptEvent
from whisper_runtime.captions import CommittedTranscript


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def strict(data: bytes):
    def pairs(values):
        result = {}
        for key, value in values:
            assert key not in result, f"duplicate key: {key}"
            result[key] = value
        return result

    def reject(value):
        raise ValueError(value)

    return json.loads(data, object_pairs_hook=pairs, parse_constant=reject)


def distance(observed: str, reference: str):
    left, right = re.findall(r"\w+", observed.casefold()), re.findall(r"\w+", reference.casefold())
    row = list(range(len(right) + 1))
    for index, token in enumerate(left, 1):
        following = [index]
        for column, target in enumerate(right, 1):
            following.append(min(following[-1] + 1, row[column] + 1, row[column - 1] + (token != target)))
        row = following
    return row[-1], len(right)


def main() -> None:
    preflight = strict((HERE / "release-soak-preflight.json").read_bytes())
    result_bytes = (HERE / "release-soak.json").read_bytes()
    result = strict(result_bytes)
    terminal_bytes = (HERE / "smoke.terminal.json").read_bytes()
    failure = strict(terminal_bytes)
    candidate = strict((ROOT / "evidence/release-candidate-local-2026-09-07.json").read_bytes())
    for relative, expected in candidate["source_sha256"].items():
        assert sha((ROOT / relative).read_bytes()) == expected
    assert result["specification"] == {key: preflight[key] for key in ("budget", "input", "source")}
    assert result["failure"] == failure
    assert result["status"] == "failed" and result["qualified"] is False
    assert result["ephemeral_context_exit_completed"] is True
    assert result["phases"] == []
    assert result["suite_done"]["status"] == "failed"
    assert result["suite_done"]["error_code"] == "memory_gate"
    assert failure["status"] == "failed" and failure["type"] == "phase_failed"
    assert failure["phase"] == "smoke" and failure["error_code"] == "memory_gate"
    assert failure["cleanup_verified"] is True
    receipt = failure["event_receipt"]
    assert receipt["path"] == "smoke.events.jsonl" and receipt["partial"] is True
    raw = (HERE / receipt["path"]).read_bytes()
    assert len(raw) == receipt["size_bytes"] and sha(raw) == receipt["sha256"]
    assert raw.endswith(b"\n")
    records = [strict(line) for line in raw.splitlines()]
    assert len(records) == receipt["event_count"] == 30
    transcript = CommittedTranscript()
    counts = {}
    last_elapsed = -1
    for record in records:
        assert record["type"] == "event" and record["phase"] == "smoke"
        elapsed = record["worker_elapsed_ns"]
        assert type(elapsed) is int and elapsed >= last_elapsed
        last_elapsed = elapsed
        event = record["event"] | {"kind": StreamEventKind(record["event"]["kind"])}
        transcript.accept(TranscriptEvent(**event))
        counts[record["event"]["kind"]] = counts.get(record["event"]["kind"], 0) + 1
    terminal = failure["terminal_before_gate"]
    metadata, metrics = terminal["metadata"], terminal["metrics"]
    expected_smoke = preflight["input"]["phases"][0]
    assert transcript.final and transcript.head == expected_smoke["sample_count"] == 744800
    assert transcript.sequence == terminal["event_count"] == metrics["events_emitted"] == 30
    assert counts["final"] == terminal["final_count"] == 1
    assert terminal["last_event_kind"] == "final"
    assert terminal["status"] == "completed" and terminal["type"] == "phase_done"
    assert terminal["source_eof_received"] is True
    assert terminal["offered_samples"] == metrics["accepted_samples"] == metrics["committed_samples"] == transcript.head
    assert metrics["buffered_samples"] == 0
    assert terminal["eof_chunks"] == metrics["accepted_chunks"] == 2328
    assert metrics["accepted_sha256"] == expected_smoke["sha256"]
    assert metrics["decode_count"] == 25
    assert metadata["source_digest"] == preflight["source"]["digest"]
    assert terminal["profile"] == preflight["input"]["profile"]
    assert metadata["stream_config"] == terminal["profile"]["stream_config"]
    assert metadata["instance_id"] == failure["instance_id"] == result["suite_done"]["instance_id"]
    assert metadata["capacity_restored"] is True and metadata["model_unchanged"] is True
    text = transcript.render("txt")
    word_edits, reference_words = distance(text, preflight["input"]["smoke_reference"])
    assert (word_edits, reference_words) == (7, 114)
    assert terminal["smoke_score"]["word_edit_distance"] == word_edits
    assert terminal["smoke_score"]["reference_word_count"] == reference_words
    assert word_edits / reference_words <= preflight["input"]["max_smoke_word_edit_rate"]
    memory = failure["memory"]
    policy = preflight["input"]["memory_policy"]
    assert terminal["memory"] == memory
    assert memory["rss_bytes"] > policy["rss_ceiling_bytes"]
    assert memory["reserved_bytes"] <= policy["reserved_ceiling_bytes"]
    assert "memory_baseline" not in terminal
    journal = [strict(line) for line in (HERE / "release-soak.attempt.jsonl").read_bytes().splitlines()]
    assert journal[-1]["event"] == "attempt-finished" and journal[-1]["status"] == "failed"
    assert journal[-1]["output_sha256"] == sha(result_bytes)
    audit = {
        "scope": "local read-only event projection and receipt audit; no remote calls, inference or new paid attempts",
        "result": "failed_at_smoke_memory_gate",
        "four_hour_qualification": False,
        "completed_hour_phases": 0,
        "event_receipt_verified": {"bytes": len(raw), "sha256": sha(raw), "events": len(records), "partial": True},
        "committed_transcript_projection": {"all_revisions_valid": True, "coverage_samples": transcript.head, "duration_seconds": transcript.head / 16000, "event_counts": counts, "text_sha256": sha(text.encode()), "nonempty_captions": sum(bool(c.text.strip()) for c in transcript.captions)},
        "reported_terminal_counters_consistent": {"elapsed_seconds": terminal["elapsed_seconds"], "elapsed_clock_scope": "Starts after owner.factory; excludes model initialization and build, not startup-inclusive end-to-end latency", "chunks": terminal["eof_chunks"], "decode_count": metrics["decode_count"], "reported_input_hash_matches_preflight": True, "cleanup_and_capacity_restored_reported": True},
        "word_score_independently_recomputed": {"word_edits": word_edits, "reference_words": reference_words, "rate": word_edits / reference_words, "registered_smoke_quality_threshold": preflight["input"]["max_smoke_word_edit_rate"]},
        "memory_gate": {"process_rss_bytes": memory["rss_bytes"], "registered_rss_ceiling_bytes": policy["rss_ceiling_bytes"], "rss_excess_bytes": memory["rss_bytes"] - policy["rss_ceiling_bytes"], "gpu_allocated_bytes": memory["allocated_bytes"], "gpu_peak_allocated_bytes": memory["peak_allocated_bytes"], "gpu_reserved_bytes": memory["reserved_bytes"], "gpu_reserved_ceiling_bytes": policy["reserved_ceiling_bytes"], "post_smoke_baseline_established": False, "leak_or_mapping_origin_inferred": False},
        "source_proof": {"runtime_modules_unchanged": 32, "source_digest": metadata["source_digest"], "archive_sha256": sha((HERE / "approved-source.zip").read_bytes()), "result_specification_matches_preflight": True},
        "result_sha256": sha(result_bytes),
        "terminal_sha256": sha(terminal_bytes),
        "attempt_finish_output_digest_verified": True,
        "app_id": result["app_id"],
        "ephemeral_context_exit_completed": True,
        "remote_stopped_tasks_zero": "Root later verified zero active tasks and Modal reported stopped_at 2026-09-07 02:52:50 UTC / 10:52:50 +08; query time unavailable; no new status request by local auditor",
        "additional_paid_attempts_authorized": False,
    }
    (HERE / "smoke-failure-local-audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
