"""Read-only source audit; does not import the harness, SDK or network code."""

from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import json
import tarfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PREFLIGHT = HERE / "release-soak-preflight.json"
ARCHIVE = HERE / "approved-source.zip"
OLD_DIRECTORY = HERE.parent / "release-soak-20260907-frozen-v2"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value: object) -> str:
    return sha(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode())


def main() -> None:
    new = json.loads(PREFLIGHT.read_bytes())
    old = json.loads((OLD_DIRECTORY / "release-soak-preflight.json").read_bytes())
    candidate = json.loads((ROOT / "evidence/release-candidate-local-2026-09-07.json").read_bytes())
    source = new["source"]
    assert len(source["files"]) == 50
    assert len(source["review_files_not_uploaded"]) == 3
    assert canonical(source["files"]) == source["digest"]
    assert canonical(source["review_files_not_uploaded"]) == source["review_digest"]
    upload_bytes = sum(record["size_bytes"] for record in source["files"])
    assert upload_bytes == 1_035_453
    expected_names = {"release-soak-preflight.json"}
    with zipfile.ZipFile(ARCHIVE) as archive:
        assert archive.testzip() is None
        assert archive.read("release-soak-preflight.json") == PREFLIGHT.read_bytes()
        for key, prefix in (("files", "source"), ("review_files_not_uploaded", "review")):
            for record in source[key]:
                name = prefix + "/" + record["path"]
                expected_names.add(name)
                data = archive.read(name)
                assert sha(data) == record["sha256"] and len(data) == record["size_bytes"], name
                assert data == (ROOT / record["path"]).read_bytes(), name
        assert len(archive.namelist()) == len(expected_names) == 54
        assert set(archive.namelist()) == expected_names
        assert len(candidate["source_sha256"]) == 32
        for name, expected in candidate["source_sha256"].items():
            assert sha(archive.read("source/" + name)) == expected, name
        harness = archive.read("source/infra/modal_release_soak.py")
    changes = {}
    for key in ("files", "review_files_not_uploaded"):
        before = {record["path"]: record for record in old["source"][key]}
        after = {record["path"]: record for record in source[key]}
        assert set(before) == set(after)
        changes[key] = [name for name in sorted(before) if before[name] != after[name]]
    assert changes["files"] == ["infra/modal_release_soak.py"]
    assert new["input"] == old["input"], "registered workload changed"
    assert {key: value for key, value in new["budget"].items() if key not in {"sdk_retry_policy", "generator_retries_supported"}} == old["budget"]
    candidate_sdist = ROOT / "artifacts/release-validation-20260907/dist-candidate/whisper_execution_runtime-0.1.0.dev0.tar.gz"
    with tarfile.open(candidate_sdist, "r:gz") as archive:
        member = next(member for member in archive.getmembers() if member.name.endswith("/infra/modal_release_soak.py"))
        previous_harness = archive.extractfile(member).read()
    old_harness_hash = next(record["sha256"] for record in old["source"]["files"] if record["path"] == "infra/modal_release_soak.py")
    assert sha(previous_harness) == old_harness_hash
    difference = "".join(difflib.unified_diff(previous_harness.decode().splitlines(keepends=True), harness.decode().splitlines(keepends=True), fromfile="candidate/infra/modal_release_soak.py", tofile="approved/infra/modal_release_soak.py"))
    (HERE / "harness-sdkfix.diff").write_text(difference, encoding="utf-8")
    old_journal = [json.loads(line) for line in (OLD_DIRECTORY / "release-soak.attempt.jsonl").read_text().splitlines()]
    assert [event["event"] for event in old_journal] == ["attempt-started", "attempt-finished"]
    assert old_journal[-1]["status"] == "failed"
    elapsed_ms = (dt.datetime.fromisoformat(old_journal[-1]["at"]) - dt.datetime.fromisoformat(old_journal[0]["at"])).total_seconds() * 1000
    old_result = json.loads((OLD_DIRECTORY / "release-soak.json").read_bytes())
    assert old_result["error_type"] == "InvalidError" and old_result["qualified"] is False
    journal = [json.loads(line) for line in (HERE / "release-soak.attempt.jsonl").read_text().splitlines()]
    app_events = [event for event in journal if event["event"] == "app-started"]
    assert len(app_events) == 1 and app_events[0]["app_id"] == "ap-pABNi973B2Un3GiEhrHvNB"
    result = {
        "scope": "local source archive audit only; no remote or paid operations",
        "archive_sha256": sha(ARCHIVE.read_bytes()),
        "preflight_sha256": sha(PREFLIGHT.read_bytes()),
        "uploaded_files_verified": 50,
        "uploaded_bytes": upload_bytes,
        "review_only_files_verified": 3,
        "archive_entries_including_preflight": 54,
        "source_digest": source["digest"],
        "review_digest": source["review_digest"],
        "changed_from_failed_attempt": changes,
        "candidate_runtime_hashes_unchanged": 32,
        "registered_input_profile_and_phases_unchanged": True,
        "budget_unchanged_except_sdk_capability_disclosure": True,
        "initial_local_failure": {"error_type": old_result["error_type"], "elapsed_ms": round(elapsed_ms, 3), "journal_has_app_started": False, "qualified": False},
        "current_app_id": app_events[0]["app_id"],
        "app_started_at": app_events[0]["at"],
        "client_exec_session_id_from_parent": 24278,
        "additional_paid_attempts_authorized": False,
    }
    (HERE / "approved-source-local-audit.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    print(difference)


if __name__ == "__main__":
    main()
