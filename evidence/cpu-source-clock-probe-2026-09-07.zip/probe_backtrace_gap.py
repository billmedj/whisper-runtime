"""Fresh local CPU heartbeat probe of unchanged Whisper backtrace; no audio/GPU."""

from __future__ import annotations

import ctypes
import hashlib
import json
import platform
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MANIFEST = ROOT / ".tmp-native/manifest.json"
setup = json.loads(MANIFEST.read_bytes())
backend = Path(setup["backend"]["path"])
sys.path.insert(0, str(backend))

import numba  # noqa: E402
import numpy as np  # noqa: E402
import torch  # noqa: E402
from whisper.timing import backtrace  # noqa: E402

PERIOD_NS = 20_000_000
assert not backtrace.signatures, "probe requires a fresh unspecialized dispatcher"
assert torch.version.cuda is None, "run only with the existing CPU-only Torch build"
assert not torch.cuda.is_initialized()


def phase(name, operation):
    ticks = []
    stop, ready = threading.Event(), threading.Event()
    origin = time.perf_counter_ns()

    def heartbeat():
        due = origin + PERIOD_NS
        ready.set()
        while not stop.is_set():
            if stop.wait(max(0.0, (due - time.perf_counter_ns()) / 1e9)):
                return
            actual = time.perf_counter_ns()
            ticks.append(
                {
                    "due_ns": due - origin,
                    "actual_ns": actual - origin,
                    "lateness_ns": max(0, actual - due),
                }
            )
            due += PERIOD_NS

    worker = threading.Thread(target=heartbeat, name="synthetic-input-heartbeat")
    worker.start()
    assert ready.wait(1)
    time.sleep(0.1)  # Allow baseline ticks before the measured operation.
    begin = time.perf_counter_ns()
    try:
        result = operation()
        end = time.perf_counter_ns()
        time.sleep(0.1)  # Record overdue ticks even if the operation held the GIL.
    finally:
        stop.set()
        worker.join(timeout=2)
        assert not worker.is_alive()
    gaps = [
        right["actual_ns"] - left["actual_ns"] for left, right in zip(ticks, ticks[1:])
    ]
    selected = [row for row in ticks if begin - origin <= row["due_ns"] <= end - origin]
    return {
        "phase": name,
        "operation_start_ns": begin - origin,
        "operation_end_ns": end - origin,
        "operation_wall_ns": end - begin,
        "heartbeat_period_ns": PERIOD_NS,
        "heartbeat_ticks": len(ticks),
        "max_heartbeat_lateness_ns": max(row["lateness_ns"] for row in ticks),
        "max_heartbeat_gap_ns": max(gaps, default=0),
        "deadlines_during_operation": len(selected),
        "max_lateness_for_deadlines_during_operation_ns": max(
            (row["lateness_ns"] for row in selected), default=None
        ),
        "ticks_later_than_250ms": sum(
            row["lateness_ns"] > 250_000_000 for row in ticks
        ),
        "result_sha256": hashlib.sha256(result.tobytes()).hexdigest()
        if isinstance(result, np.ndarray)
        else None,
        "result_shape": list(result.shape) if isinstance(result, np.ndarray) else None,
        "raw_heartbeat_ticks": ticks,
    }


def main():
    # Match the strided int32 NumPy view used by dtw_cuda after unskewing its
    # trace. Shape is the requested synthetic 129 x 1501, not captured audio.
    trace = np.zeros((129, 1631), dtype=np.int32)[:, :1501]
    before = [str(signature) for signature in backtrace.signatures]
    phases = [phase("sleep_releases_gil_control", lambda: time.sleep(0.6))]
    phases.append(phase("cold_backtrace", lambda: backtrace(trace)))
    after_cold = [str(signature) for signature in backtrace.signatures]
    phases.append(phase("warm_backtrace", lambda: backtrace(trace)))
    assert phases[-1]["result_sha256"] == phases[-2]["result_sha256"]

    # ctypes.PyDLL deliberately retains the GIL. Windows Sleep is a positive
    # detector control only; the backend function is not replaced or patched.
    if sys.platform == "win32":
        gil_sleep = ctypes.PyDLL("kernel32").Sleep
        gil_sleep.argtypes, gil_sleep.restype = [ctypes.c_ulong], None
        phases.append(phase("sleep_holds_gil_positive_control", lambda: gil_sleep(600)))

    report = {
        "scope": "One fresh Windows CPU process; synthetic trace only; unchanged cached Whisper function; not proof of the capped T4 failure's cause.",
        "platform": platform.platform(),
        "python": platform.python_version(),
        "numpy": np.__version__,
        "numba": numba.__version__,
        "torch": torch.__version__,
        "cuda_initialized": torch.cuda.is_initialized(),
        "backend_recorded_tree": setup["backend"]["tree"],
        "timing_py_sha256": hashlib.sha256(
            (backend / "whisper/timing.py").read_bytes()
        ).hexdigest(),
        "backtrace_targetoptions": backtrace.targetoptions,
        "backtrace_signatures_before": before,
        "backtrace_signatures_after_cold": after_cold,
        "backtrace_signatures_after_warm": [
            str(signature) for signature in backtrace.signatures
        ],
        "synthetic_trace": {
            "shape": list(trace.shape),
            "dtype": str(trace.dtype),
            "strides_bytes": list(trace.strides),
            "c_contiguous": bool(trace.flags.c_contiguous),
            "recipe": "zero-filled backing int32[129,1631], view[:, :1501]",
        },
        "phases": phases,
        "limits": [
            "Imports finish before measurement.",
            "This measures heartbeat scheduling delay, not GIL ownership directly.",
            "Cold/warm order and one process cannot exclude operating-system scheduling effects.",
            "No runtime/backend/threshold change, checkpoint load, transcription, network or GPU work.",
        ],
    }
    output = Path(__file__).with_name("backtrace-gap-local-20260907.json")
    with output.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(report, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    print(
        json.dumps(
            {
                "output": output.relative_to(ROOT).as_posix(),
                "phases": [
                    {
                        key: value
                        for key, value in row.items()
                        if key != "raw_heartbeat_ticks"
                    }
                    for row in phases
                ],
                "signatures": after_cold,
                "cuda_initialized": report["cuda_initialized"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
