"""Deterministic local receipt mutations; no native imports, network or GPU."""

import copy
import json
import subprocess
import sys
import unittest
from pathlib import Path

import audit_capacity as audit

HERE = Path(__file__).resolve().parent


def frame(sequence, late):
    end = min((sequence + 1) * 320, 744800)
    due = end / 16000
    return {
        "sequence": sequence,
        "start_sample": sequence * 320,
        "end_sample": end,
        "due_elapsed_seconds": due,
        "wake_elapsed_seconds": due + late,
        "wake_lateness_seconds": late,
    }


def clock(*, frames=2, failed=False):
    last = frame(frames if failed else frames - 1, 0.251 if failed else 0.002)
    return {
        "schema_version": "source-clock-v2",
        "clock": "time.monotonic",
        "origin_monotonic_seconds": 100.0,
        "max_wake_lateness_seconds": 0.251 if failed else 0.005,
        "max_wake_frame": copy.deepcopy(last) if failed else frame(0, 0.005),
        "max_yield_resume_seconds": 0.001 if frames else 0.0,
        "max_yield_resume_interval": {
            "sequence": 0,
            "start_sample": 0,
            "end_sample": 320,
            "yield_elapsed_seconds": 0.026,
            "resume_elapsed_seconds": 0.027,
            "gap_seconds": 0.001,
        }
        if frames
        else None,
        "offered_frames": frames,
        "offered_samples": min(frames * 320, 744800),
        "last_yield_sequence": frames - 1 if frames else None,
        "last_yield_end_sample": min(frames * 320, 744800) if frames else None,
        "last_attempt": last,
        "failed_frame": copy.deepcopy(last) if failed else None,
    }


def operation():
    return {
        "name": "dtw_cuda",
        "session": "session-1",
        "clock": "time.monotonic",
        "start_monotonic_seconds": 100.021,
        "end_monotonic_seconds": 100.027,
        "wall_ns": 5_000_000,
    }


class ClockTests(unittest.TestCase):
    def test_valid_partial_complete_and_failed_v2(self):
        audit.source_clock(clock(), completed=False, expected_version="source-clock-v2")
        audit.source_clock(clock(frames=2328), completed=True, elapsed_limit=47.1)
        for frames in (0, 2):
            audit.source_clock(
                clock(frames=frames, failed=True), completed=False, source_late=True
            )

    def test_v2_mutations_fail(self):
        mutations = (
            (("schema_version",), "source-clock-v1"),
            (("clock",), "time.perf_counter"),
            (("origin_monotonic_seconds",), float("nan")),
            (("origin_monotonic_seconds",), -1),
            (("last_yield_sequence",), True),
            (("max_wake_frame",), None),
            (("max_wake_frame", "sequence"), 2),
            (("max_wake_frame", "start_sample"), 1),
            (("max_wake_frame", "due_elapsed_seconds"), 0.04),
            (("max_wake_frame", "wake_lateness_seconds"), 0.007),
            (("max_wake_lateness_seconds",), 0.006),
            (("max_yield_resume_interval",), None),
            (("max_yield_resume_interval", "sequence"), 2),
            (("max_yield_resume_interval", "yield_elapsed_seconds"), 0.001),
            (("max_yield_resume_interval", "resume_elapsed_seconds"), 0.025),
            (("max_yield_resume_interval", "gap_seconds"), 0.002),
            (("max_yield_resume_seconds",), 0.002),
        )
        for path, invalid in mutations:
            with self.subTest(path=path, invalid=invalid):
                value = clock()
                parent = value
                for key in path[:-1]:
                    parent = parent[key]
                parent[path[-1]] = invalid
                with self.assertRaises((AssertionError, ValueError)):
                    audit.source_clock(
                        value, completed=False, expected_version="source-clock-v2"
                    )

    def test_frozen_schema_forbids_downgrade(self):
        value = clock()
        for key in (
            "clock",
            "origin_monotonic_seconds",
            "max_wake_frame",
            "max_yield_resume_interval",
        ):
            value.pop(key)
        value["schema_version"] = "source-clock-v1"
        audit.source_clock(value, completed=False, expected_version="source-clock-v1")
        with self.assertRaisesRegex(AssertionError, "frozen source"):
            audit.source_clock(
                value, completed=False, expected_version="source-clock-v2"
            )

    def test_completed_coverage_and_deadline_still_fail_closed(self):
        for value in (clock(), clock(failed=True)):
            with self.assertRaises(AssertionError):
                audit.source_clock(value, completed=True)
        with self.assertRaisesRegex(AssertionError, "session terminal"):
            audit.source_clock(clock(frames=2328), completed=True, elapsed_limit=46.55)

    def test_exact_lateness_threshold_is_unchanged(self):
        value = clock(frames=2328)
        maximum = frame(0, 0.25)
        value.update(max_wake_frame=maximum, max_wake_lateness_seconds=0.25)
        # Place the interval later than this maximum's wake.
        value["max_yield_resume_interval"].update(
            yield_elapsed_seconds=0.271, resume_elapsed_seconds=0.272
        )
        audit.source_clock(value, completed=True)
        maximum["wake_elapsed_seconds"] += 0.000001
        maximum["wake_lateness_seconds"] += 0.000001
        value["max_wake_lateness_seconds"] += 0.000001
        with self.assertRaises(AssertionError):
            audit.source_clock(value, completed=True)

    def test_failed_frame_must_be_latest_argmax(self):
        value = clock(failed=True)
        value["max_wake_frame"] = frame(0, 0.251)
        with self.assertRaisesRegex(AssertionError, "failed argmax"):
            audit.source_clock(value, completed=False, source_late=True)

    def test_yield_cannot_precede_same_frame_maximum_wake(self):
        value = clock()
        value["max_yield_resume_interval"].update(
            yield_elapsed_seconds=0.023, resume_elapsed_seconds=0.024
        )
        with self.assertRaisesRegex(AssertionError, "before maximum wake"):
            audit.source_clock(value, completed=False)


class PrefixTests(unittest.TestCase):
    def setUp(self):
        self.seed = b"\x12\x34" * 1000
        self.clock = clock(failed=True)
        self.prefix = {
            "offered_samples": 640,
            "offered_sha256": audit.sha(self.seed[:1280]),
            "native_accepted_samples": 640,
        }

    def validate(self, value, **kwargs):
        return audit.failure_prefix(
            value, self.clock, self.seed, source_late=True, **kwargs
        )

    def test_prefix_hash_and_native_acceptance_are_separate(self):
        self.validate(self.prefix, committed_samples=320)
        for key, invalid in (
            ("offered_sha256", "0" * 64),
            ("offered_samples", 320),
            ("native_accepted_samples", 641),
            ("native_accepted_samples", True),
            ("native_accepted_samples", None),
            ("native_accepted_samples", 320),
        ):
            with self.subTest(key=key, invalid=invalid):
                with self.assertRaises(AssertionError):
                    self.validate({**self.prefix, key: invalid})

    def test_committed_cannot_exceed_accepted(self):
        with self.assertRaisesRegex(AssertionError, "accepted prefix bound"):
            self.validate(self.prefix, committed_samples=960)

    def test_non_source_late_can_report_missing_native_counter_honestly(self):
        value = {**self.prefix, "native_accepted_samples": None}
        audit.failure_prefix(value, self.clock, self.seed, source_late=False)
        value["accepted_count_error_type"] = "RuntimeError"
        audit.failure_prefix(value, self.clock, self.seed, source_late=False)
        with self.assertRaises(AssertionError):
            self.validate(value)

    def test_terminal_prefix_mismatch_fails(self):
        terminal = {"source_clock": self.clock, "metrics": {"accepted_samples": 320}}
        with self.assertRaisesRegex(AssertionError, "terminal prefix parity"):
            self.validate(self.prefix, terminal=terminal)


class OperationTests(unittest.TestCase):
    def test_shared_origin_reports_overlap_not_causality(self):
        result = audit.operation_clock(operation(), clock(), elapsed_limit=0.05)
        self.assertAlmostEqual(result["argmax_overlap_seconds"]["max_wake"], 0.004)
        self.assertAlmostEqual(
            result["argmax_overlap_seconds"]["max_yield_resume"], 0.001
        )
        self.assertTrue(result["overlap_does_not_establish_causality"])

    def test_interval_and_origin_mutations_fail(self):
        for key, invalid in (
            ("clock", "wall"),
            ("start_monotonic_seconds", 99),
            ("end_monotonic_seconds", 100.0),
            ("wall_ns", 9_000_000),
            ("wall_ns", True),
            ("start_monotonic_seconds", float("inf")),
        ):
            with self.subTest(key=key):
                with self.assertRaises(AssertionError):
                    audit.operation_clock({**operation(), key: invalid}, clock())
        with self.assertRaises(AssertionError):
            audit.operation_clock(operation(), clock(), elapsed_limit=0.026)


class HistoricalTests(unittest.TestCase):
    def test_historical_pass_and_failure_remain_distinct(self):
        for name, expected_exit, expected_status, version in (
            ("capacity-clock-4g-20260907", 0, "passed", "source-clock-v1"),
            ("capacity-smoke-4g-20260907", 1, "failed-run-inspected", None),
        ):
            with self.subTest(name=name):
                result = subprocess.run(
                    [
                        sys.executable,
                        "-B",
                        str(HERE / "audit_capacity.py"),
                        "--directory",
                        str(audit.ROOT / "artifacts/modal-memory-diagnostic" / name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                self.assertEqual(
                    result.returncode, expected_exit, result.stdout + result.stderr
                )
                report = json.loads(result.stdout)
                self.assertEqual(report["audit_status"], expected_status, report)
                self.assertEqual(report["source_clock_version"], version)
                self.assertFalse(report["release_qualified"])

    def test_frozen_v2_schema_and_resource_gate_detected(self):
        frozen = (
            audit.ROOT
            / "artifacts/modal-memory-diagnostic/verified-startup-clock-20260907/source"
        )
        self.assertEqual(audit.resource_definition(frozen), "source-clock-v2")


if __name__ == "__main__":
    unittest.main()
