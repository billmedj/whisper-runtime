"""Prepare one explicitly authorized T4 memory attribution diagnostic.

Imports/preflight are local only. Two identical 46.55s source-paced sessions,
not release qualification. No allocator settings, RAM gates, or numerics change.
"""

from __future__ import annotations

import argparse
import gc
import hashlib
import importlib
import json
import os
import queue
import re
import sys
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace

from infra import modal_release_soak as soak

ROOT, live, prior = soak.ROOT, soak.live, soak.prior
PRODUCER = "infra/modal_memory_diagnostic.py"
TEST = "tools/test_modal_memory_diagnostic.py"
TIMEOUT = 300
SESSIONS = ("session-1", "session-2")
REQUIRED_SNAPSHOTS = (
    "before_native_imports",
    "after_torch_import",
    "after_native_imports",
    "after_model_load",
    "after_model_fingerprint",
    "session-1_closed_gc",
    "session-2_closed_gc",
)
ENVIRONMENT = (
    "NUMBA_NUM_THREADS",
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "CUDA_MODULE_LOADING",
)
require = soak.require


def memory_sample(proc=Path("/proc/self")):
    """Observe Linux and *already imported/initialized* native state only.

    No Torch/Numba import, device discovery, thread-pool initialization, cache
    purge or peak-counter reset. Partial measurements explicitly retain errors.
    """
    result = {
        "errors": [],
        "environment": {key: os.environ.get(key) for key in ENVIRONMENT},
    }

    def observe(name, operation):
        try:
            result[name] = operation()
        except Exception as error:
            result[name] = None
            result["errors"].append(
                {"component": name, "error_type": type(error).__name__}
            )

    def smaps():
        fields = {}
        for line in (proc / "smaps_rollup").read_text().splitlines():
            name, separator, value = line.partition(":")
            if separator and value.strip().endswith("kB"):
                amount, unit = value.split()
                require(unit == "kB" and int(amount) >= 0, "invalid_smaps")
                fields[name] = int(amount) * 1024
        require(
            all(
                key in fields
                for key in (
                    "Rss",
                    "Pss",
                    "Private_Clean",
                    "Private_Dirty",
                    "Shared_Clean",
                    "Shared_Dirty",
                )
            ),
            "incomplete_smaps",
        )
        return {
            "fields_bytes": fields,
            "private_bytes": sum(
                fields.get(key, 0)
                for key in ("Private_Clean", "Private_Dirty", "Private_Hugetlb")
            ),
            "shared_bytes": sum(
                fields.get(key, 0)
                for key in ("Shared_Clean", "Shared_Dirty", "Shared_Hugetlb")
            ),
        }

    def statm():
        values = [int(value) for value in (proc / "statm").read_text().split()]
        require(len(values) == 7 and min(values) >= 0, "invalid_statm")
        page = os.sysconf("SC_PAGE_SIZE")
        return {
            "page_size_bytes": page,
            "pages": values,
            "rss_bytes": values[1] * page,
            "shared_bytes": values[2] * page,
        }

    def threads():
        for line in (proc / "status").read_text().splitlines():
            if line.startswith("Threads:"):
                value = int(line.split(":", 1)[1])
                require(value > 0, "invalid_threads")
                return value
        raise soak.SoakError("missing_threads")

    observe("smaps_rollup", smaps)
    observe("statm", statm)
    observe("threads", threads)
    torch = sys.modules.get("torch")
    result["torch_imported"] = torch is not None
    result["whisper_imported"] = "whisper" in sys.modules
    result["numba_imported"] = "numba" in sys.modules
    numba_config = sys.modules.get("numba.core.config")
    result["numba_config"] = (
        {
            name: getattr(numba_config, name, None)
            for name in (
                "NUMBA_NUM_THREADS",
                "NUMBA_DEFAULT_NUM_THREADS",
                "THREADING_LAYER",
            )
        }
        if numba_config is not None
        else None
    )
    result["cuda"] = {"initialized": False} if torch is None else None
    if torch is not None:
        observe(
            "torch_threads",
            lambda: {
                "intra_op": torch.get_num_threads(),
                "inter_op": torch.get_num_interop_threads(),
            },
        )

        def cuda():
            if not torch.cuda.is_initialized():
                return {"initialized": False}
            torch.cuda.synchronize(0)
            return {
                "initialized": True,
                **{
                    name: int(getattr(torch.cuda, method)(0))
                    for name, method in (
                        ("allocated_bytes", "memory_allocated"),
                        ("reserved_bytes", "memory_reserved"),
                        ("peak_allocated_bytes", "max_memory_allocated"),
                        ("peak_reserved_bytes", "max_memory_reserved"),
                    )
                },
            }

        observe("cuda", cuda)
    return result


class Observer:
    """Scoped observation of the unmodified native factory and DTW callables."""

    def __init__(self, emit, memory):
        self.emit, self.memory = emit, memory
        self.session = None
        self.seen, self.counts, self.restores = set(), {}, []
        self.sampling_errors = False

    def capture(self, phase):
        try:
            sample = self.memory()
        except Exception as error:
            sample = {
                "errors": [{"component": "sampler", "error_type": type(error).__name__}]
            }
        self.sampling_errors |= bool(sample.get("errors"))
        self.seen.add(phase)
        self.emit(
            {
                "type": "memory",
                "phase": phase,
                "session": self.session,
                "sample": sample,
            }
        )

    def wrap_dtw(self):
        # Whisper imports timing itself. Do not import optional backend modules
        # or invoke Numba APIs merely to make observation available.
        timing = sys.modules.get("whisper.timing")
        for name in ("dtw_cpu", "dtw_cuda"):
            original = getattr(timing, name, None)
            if not callable(original):
                continue
            self.counts[name] = 0

            def measured(*args, _name=name, _original=original, **kwargs):
                self.counts[_name] += 1
                first = self.counts[_name] == 1
                if first:
                    self.capture("first_" + _name + "_before")
                started = time.perf_counter_ns()
                status = "failed"
                try:
                    result = _original(*args, **kwargs)
                    status = "completed"
                    return result
                finally:
                    elapsed = time.perf_counter_ns() - started
                    if first:
                        matrix = args[0] if args else kwargs.get("x")
                        self.emit(
                            {
                                "type": "operation",
                                "name": _name,
                                "session": self.session,
                                "status": status,
                                "shape": [int(n) for n in getattr(matrix, "shape", ())],
                                "wall_ns": elapsed,
                                "first_call_only": True,
                            }
                        )
                        self.capture("first_" + _name + "_after")

            setattr(timing, name, measured)
            self.restores.append((timing, name, original))

    @contextmanager
    def factory_scope(self):
        setup = importlib.import_module("whisper_runtime.native_setup")
        original_imports, load, fingerprint = (
            live.importlib,
            setup._load_model,
            setup._fingerprint,
        )

        def imported(name, *args, **kwargs):
            module = original_imports.import_module(name, *args, **kwargs)
            if name == "torch" and "after_torch_import" not in self.seen:
                self.capture("after_torch_import")
            if name == "whisper" and "after_native_imports" not in self.seen:
                self.capture("after_native_imports")
                self.wrap_dtw()
            return module

        def loaded(*args, **kwargs):
            model = load(*args, **kwargs)
            self.capture("after_model_load")
            return model

        def fingerprinted(*args, **kwargs):
            value = fingerprint(*args, **kwargs)
            if "after_model_fingerprint" not in self.seen:
                self.capture("after_model_fingerprint")
            return value

        # Replace only the harness module's importlib reference, not the global
        # import system. The factory and inference have one owner thread.
        live.importlib = SimpleNamespace(import_module=imported)
        setup._load_model, setup._fingerprint = loaded, fingerprinted
        try:
            yield
        finally:
            live.importlib = original_imports
            setup._load_model, setup._fingerprint = load, fingerprint

    def close(self):
        for module, name, original in reversed(self.restores):
            setattr(module, name, original)
        self.restores.clear()


def input_plan(root=ROOT):
    seed, original = live.input_plan(root, short_only=True)
    require(len(seed) // 2 == 744800, "registered_source_length")
    return seed, {
        "schema_version": "native-memory-diagnostic-v1",
        "profile": soak.profile_contract(),
        "seed_sha256": prior._sha(seed),
        "seed_samples": len(seed) // 2,
        "recipe": original["recipe"],
        "smoke_reference": original["smoke_reference"],
        "max_smoke_word_edit_rate": original["max_smoke_word_edit_rate"],
        "input_allowlist": {
            key: original[key]
            for key in (
                "main_case",
                "main_sha256",
                "noisy_source_case",
                "noisy_prefix_samples",
                "noisy_prefix_sha256",
            )
        },
        "phases": [
            {
                "phase": name,
                "sample_count": len(seed) // 2,
                "sha256": prior._sha(seed),
                "timeout_seconds": 190,
            }
            for name in SESSIONS
        ],
        "outer_seconds": TIMEOUT,
        "drain_timeout_seconds": 30,
        "max_source_lateness_seconds": 0.25,
        "memory_is_observational": True,
        "release_memory_gates_unchanged": dict(soak.MEMORY_POLICY),
        "required_snapshots": list(REQUIRED_SNAPSHOTS),
        "environment_allowlist": list(ENVIRONMENT),
    }


def snapshot(root=ROOT):
    existing = soak.snapshot(root)
    files = [
        *existing["files"],
        {
            "path": PRODUCER,
            "size_bytes": (Path(root) / PRODUCER).stat().st_size,
            "sha256": prior._sha((Path(root) / PRODUCER).read_bytes()),
        },
    ]
    files.sort(key=lambda item: item["path"])
    review = [
        *existing["review_files_not_uploaded"],
        {
            "path": TEST,
            "size_bytes": (Path(root) / TEST).stat().st_size,
            "sha256": prior._sha((Path(root) / TEST).read_bytes()),
        },
    ]
    review.sort(key=lambda item: item["path"])
    return {
        **existing,
        "files": files,
        "digest": prior._canonical(files),
        "review_files_not_uploaded": review,
        "review_digest": prior._canonical(review),
    }


def budget_plan():
    result = {**soak.budget_plan(), "outer_seconds": TIMEOUT}
    price = live.PRICES
    result["planning_compute_usd"] = round(
        TIMEOUT
        * (
            price["t4_per_second"]
            + 2 * price["cpu_core_per_second"]
            + 4 * price["gib_per_second"]
        )
        * price["regional_multiplier_ceiling"],
        6,
    )
    return result


def run_diagnostic(
    seed,
    plan,
    expected,
    *,
    memory=memory_sample,
    owner_factory=live.NativeOwner,
    score=None,
):
    """Bounded mailbox keeps baseline/partial snapshots visible during native work."""
    from whisper_runtime.captions import CommittedTranscript
    from whisper_runtime.cli import drive_stream

    require(plan["profile"] == soak.profile_contract(), "stale_profile")
    require(prior._sha(seed) == plan["seed_sha256"], "seed_identity")
    mailbox, cancelled, finished = (
        queue.Queue(maxsize=64),
        threading.Event(),
        threading.Event(),
    )
    started = time.monotonic()
    owner = owner_factory(expected)

    def work():
        sequence = 0

        def emit(item):
            nonlocal sequence
            require(not cancelled.is_set(), "cancelled")
            sequence += 1
            item = {
                **item,
                "sequence": sequence,
                "instance_id": owner.instance_id,
                "source_digest": expected["digest"],
            }
            soak.encode(item)
            mailbox.put(item, timeout=0.25)

        observer = Observer(emit, memory)
        stream = finalize = terminal = None
        previous_text = None
        try:
            require(
                "torch" not in sys.modules and "whisper" not in sys.modules,
                "baseline_native_already_imported",
            )
            observer.capture("before_native_imports")
            for number, stage in enumerate(plan["phases"], 1):
                observer.session = stage["phase"]
                require(
                    time.monotonic() - started + stage["sample_count"] / 16000 + 40
                    < plan["outer_seconds"],
                    "insufficient_session_budget",
                )
                emit(
                    {
                        "type": "session_started",
                        "phase": stage["phase"],
                        "session_number": number,
                    }
                )
                with observer.factory_scope():
                    stream, finalize = owner.factory(stage["phase"])
                require(
                    asdict(stream.config) == plan["profile"]["stream_config"],
                    "stale_stream_config",
                )
                transcript = CommittedTranscript()
                counters = {
                    "samples": 0,
                    "chunks": 0,
                    "events": 0,
                    "final": 0,
                    "eof": False,
                    "last": None,
                }
                digest = hashlib.sha256()
                origin = time.monotonic()

                def source():
                    for frame in soak.frames(seed, stage["sample_count"]):
                        end = counters["samples"] + len(frame) // 2
                        due = origin + end / 16000
                        require(
                            not cancelled.wait(max(0, due - time.monotonic())),
                            "cancelled",
                        )
                        require(time.monotonic() - due <= 0.25, "source_late")
                        digest.update(frame)
                        counters["samples"], counters["chunks"] = (
                            end,
                            counters["chunks"] + 1,
                        )
                        yield frame
                    counters["eof"] = True

                def event(value):
                    transcript.accept(value)
                    counters["events"] += 1
                    counters["final"] += value.kind.value == "final"
                    counters["last"] = value.kind.value
                    require(counters["events"] <= 10000, "event_limit")
                    require(
                        time.monotonic() - origin <= stage["timeout_seconds"],
                        "session_timeout",
                    )
                    emit(
                        {
                            "type": "event",
                            "phase": stage["phase"],
                            "event": asdict(value),
                        }
                    )

                drive_stream(
                    stream,
                    source(),
                    on_event=event,
                    cancel=threading.Event(),
                    live=True,
                    drain_timeout=30,
                )
                metadata = finalize()
                terminal = {
                    "type": "session_done",
                    "phase": stage["phase"],
                    "status": "completed",
                    "profile": plan["profile"],
                    "source_eof_received": counters["eof"],
                    "metrics": {
                        **asdict(stream.metrics),
                        "accepted_sha256": digest.hexdigest(),
                    },
                    "metadata": metadata,
                    "final_count": counters["final"],
                    "last_event_kind": counters["last"],
                    "eof_chunks": counters["chunks"],
                    "event_count": counters["events"],
                    "offered_samples": counters["samples"],
                    "elapsed_seconds": time.monotonic() - origin,
                }
                require(
                    transcript.final
                    and transcript.head == stage["sample_count"] == counters["samples"],
                    "coverage_gate",
                )
                require(
                    soak.stage_valid(
                        terminal,
                        stage,
                        expected,
                        plan["profile"],
                        owner.instance_id,
                        number,
                    ),
                    "stage_gate",
                )
                text = transcript.render("txt")
                require(len(text) <= 65536, "text_limit")
                difference = score or prior._corpus().b._word_difference
                terminal["score"] = difference(text, plan["smoke_reference"])
                rate = terminal["score"].get("word_edit_rate")
                require(
                    type(rate) in (float, int)
                    and 0 <= rate <= plan["max_smoke_word_edit_rate"],
                    "quality_gate",
                )
                require(
                    previous_text is None or text == previous_text,
                    "session_text_changed",
                )
                previous_text = text
                terminal["text"], terminal["text_sha256"] = (
                    text,
                    prior._sha(text.encode()),
                )
                stream = finalize = transcript = None
                gc.collect()
                observer.capture(stage["phase"] + "_closed_gc")
                emit(terminal)
                terminal = None
            require(
                set(REQUIRED_SNAPSHOTS) <= observer.seen, "missing_lifecycle_snapshot"
            )
            require(not observer.sampling_errors, "memory_sampling_incomplete")
            emit(
                {
                    "type": "diagnostic_done",
                    "status": "completed",
                    "sessions": owner.sessions,
                    "model_loads": owner.loads,
                    "dtw_calls": observer.counts,
                    "qualified": False,
                }
            )
        except BaseException as error:
            cleanup = False
            if stream is not None:
                try:
                    stream.close()
                    finalize()
                    cleanup = True
                except BaseException:
                    pass
                stream = finalize = None
            gc.collect()
            try:
                observer.capture("failure_closed_gc")
                emit(
                    {
                        "type": "diagnostic_done",
                        "status": "failed",
                        "qualified": False,
                        "error_code": soak.failure_code(
                            error, "native_memory_diagnostic_failed"
                        ),
                        "error_type": type(error).__name__,
                        "session": observer.session,
                        "cleanup_verified": cleanup,
                        "terminal_before_gate": terminal,
                        "initialization_stage": getattr(
                            owner, "initialization_stage", "scripted"
                        ),
                        "dtw_calls": observer.counts,
                    }
                )
            except (queue.Full, soak.SoakError):
                pass
        finally:
            observer.close()
            finished.set()

    thread = threading.Thread(
        target=work, name="memory-diagnostic-native-owner", daemon=True
    )
    thread.start()
    try:
        while not finished.is_set() or not mailbox.empty():
            require(
                time.monotonic() - started <= plan["outer_seconds"], "outer_timeout"
            )
            try:
                yield mailbox.get(timeout=0.1)
            except queue.Empty:
                continue
    finally:
        cancelled.set()
        thread.join(timeout=5)
        require(not thread.is_alive(), "native_owner_not_stopped")


def resources(modal, expected, plan, root):
    corpus = prior._corpus()
    qualification = corpus._helper("infra.modal_native_cuda_qualification")
    image = (
        modal.Image.debian_slim(python_version="3.13")
        .apt_install("ca-certificates", "ffmpeg", "git")
        .pip_install("torch==2.6.0", index_url="https://download.pytorch.org/whl/cu124")
        .uv_pip_install(*qualification.DIRECT_IMAGE_PACKAGES)
        .run_commands(qualification._build_command(corpus.BASE_COMMIT))
    )
    for item in expected["files"]:
        image = image.add_local_file(
            Path(root) / item["path"],
            (live.REMOTE_ROOT / item["path"]).as_posix(),
            copy=True,
        )
    image = image.env(
        {
            "PYTHONPATH": "/opt/openai-whisper:/opt/whisper-runtime/src:/opt/whisper-runtime",
            "PYTHONDONTWRITEBYTECODE": "1",
            "PYTHONNOUSERSITE": "1",
            "WHISPER_MODAL_ENABLE_WORD_CORPUS": "0",
            "WHISPER_MODAL_ENABLE_REMOTE_RESOURCES": "0",
        }
    )
    volume = modal.Volume.from_name(corpus.b.MODEL_CACHE_NAME, create_if_missing=False)
    app = modal.App("wr-memory-diagnostic-" + uuid.uuid4().hex[:12])

    @app.function(
        image=image,
        serialized=True,
        cpu=2,
        memory=4096,
        gpu="T4",
        cloud="aws",
        region="us-west",
        timeout=TIMEOUT,
        startup_timeout=180,
        min_containers=0,
        max_containers=1,
        buffer_containers=0,
        scaledown_window=2,
        single_use_containers=True,
        block_network=True,
        restrict_modal_access=True,
        include_source=False,
        volumes={corpus.b.MODEL_CACHE_MOUNT: volume.with_mount_options(read_only=True)},
    )
    def endpoint(seed):
        module = importlib.import_module("infra.modal_memory_diagnostic")
        module.prior._verify_source(expected)
        yield from module.run_diagnostic(seed, plan, expected)

    return app, endpoint


def collect(messages, directory, plan, expected):
    from whisper_runtime.adapters import StreamEventKind, TranscriptEvent
    from whisper_runtime.captions import CommittedTranscript

    result = {"status": "failed", "sessions": [], "snapshots": [], "operations": []}
    instance = active = projection = previous_text = None
    size = events = 0
    digest = hashlib.sha256()
    try:
        with (directory / "observations.jsonl").open("xb") as handle:
            for sequence, item in enumerate(messages, 1):
                require("terminal" not in result, "message_after_terminal")
                raw = soak.encode(item)
                size += len(raw)
                require(size <= 8 * 1024 * 1024, "observation_limit")
                require(
                    item["sequence"] == sequence
                    and item["source_digest"] == expected["digest"],
                    "observation_identity",
                )
                instance = instance or item["instance_id"]
                require(item["instance_id"] == instance, "worker_changed")
                handle.write(raw)
                handle.flush()
                digest.update(raw)
                kind = item["type"]
                if kind == "memory":
                    require(
                        not any(
                            row["phase"] == item["phase"] for row in result["snapshots"]
                        ),
                        "duplicate_snapshot",
                    )
                    result["snapshots"].append(item)
                elif kind == "operation":
                    result["operations"].append(item)
                elif kind == "session_started":
                    require(
                        active is None and len(result["sessions"]) < 2, "session_replay"
                    )
                    stage = plan["phases"][len(result["sessions"])]
                    require(
                        item["phase"] == stage["phase"]
                        and item["session_number"] == len(result["sessions"]) + 1,
                        "session_order",
                    )
                    active, projection, events = (
                        stage["phase"],
                        CommittedTranscript(),
                        0,
                    )
                elif kind == "event":
                    require(
                        active == item["phase"] and projection is not None,
                        "unexpected_event",
                    )
                    event = {
                        **item["event"],
                        "kind": StreamEventKind(item["event"]["kind"]),
                    }
                    projection.accept(TranscriptEvent(**event))
                    events += 1
                elif kind == "session_done":
                    require(
                        active == item["phase"]
                        and projection is not None
                        and soak.stage_valid(
                            item,
                            stage,
                            expected,
                            plan["profile"],
                            instance,
                            len(result["sessions"]) + 1,
                        ),
                        "terminal_gate",
                    )
                    require(
                        projection.final
                        and projection.head
                        == item["offered_samples"]
                        == stage["sample_count"]
                        and events == item["event_count"],
                        "event_coverage",
                    )
                    text = projection.render("txt")
                    require(
                        text == item["text"]
                        and item["text_sha256"] == prior._sha(text.encode()),
                        "text_identity",
                    )
                    require(
                        previous_text is None or previous_text == text,
                        "session_text_changed",
                    )
                    rate = item.get("score", {}).get("word_edit_rate")
                    require(
                        type(rate) in (float, int)
                        and 0 <= rate <= plan["max_smoke_word_edit_rate"],
                        "quality_gate",
                    )
                    require(
                        any(
                            row["phase"] == active + "_closed_gc"
                            for row in result["snapshots"]
                        ),
                        "missing_cleanup_snapshot",
                    )
                    result["sessions"].append(item)
                    previous_text, active, projection = text, None, None
                elif kind == "diagnostic_done":
                    result["terminal"] = item
                    if item["status"] == "completed":
                        require(
                            active is None
                            and len(result["sessions"]) == item["sessions"] == 2
                            and item["model_loads"] == 1,
                            "diagnostic_gate",
                        )
                        require(
                            set(REQUIRED_SNAPSHOTS)
                            <= {row["phase"] for row in result["snapshots"]},
                            "missing_lifecycle_snapshot",
                        )
                        require(
                            not any(
                                row["sample"].get("errors")
                                for row in result["snapshots"]
                            ),
                            "memory_sampling_incomplete",
                        )
                        result["status"] = "completed"
                else:
                    raise soak.SoakError("unexpected_message")
        if "terminal" not in result:
            result["error_code"] = "missing_terminal"
        result["observation_receipt"] = {
            "path": "observations.jsonl",
            "sha256": digest.hexdigest(),
            "size_bytes": size,
        }
        return result
    finally:
        if hasattr(messages, "close"):
            messages.close()


def run(*, replay_id, preflight=False, confirm_paid_gpu=False, root=ROOT):
    require(preflight != confirm_paid_gpu, "choose_preflight_or_confirm_paid_gpu")
    require(
        isinstance(replay_id, str)
        and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,47}", replay_id)
        and not re.fullmatch(r"CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9]", replay_id, re.I),
        "invalid_replay_id",
    )
    base = Path(root).resolve() / "artifacts/modal-memory-diagnostic"
    directory = base / replay_id
    require(directory.resolve().parent == base.resolve(), "artifact_path_redirected")
    output = directory / ("preflight.json" if preflight else "diagnostic.json")
    receipt, frozen = directory / "attempt.jsonl", directory / "source"
    require(not output.exists() and not receipt.exists(), "attempt_exists_no_retry")
    seed, plan = input_plan(root)
    expected = snapshot(root)
    specification = {
        "source": expected,
        "input": plan,
        "budget": budget_plan(),
        "qualified": False,
    }
    if preflight:
        require(not directory.exists(), "namespace_exists_no_overwrite")
        directory.mkdir(parents=True, exist_ok=False)
        for item in expected["files"]:
            data = (Path(root) / item["path"]).read_bytes()
            require(
                len(data) == item["size_bytes"] and prior._sha(data) == item["sha256"],
                "source_changed_during_freeze",
            )
            target = frozen / item["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as handle:
                handle.write(data)
        with (directory / "seed.pcm").open("xb") as handle:
            handle.write(seed)
        prior._write_result(
            output, {"status": "local-preflight-passed", **specification}
        )
        return output
    previous = json.loads((directory / "preflight.json").read_text())
    require(
        previous == {"status": "local-preflight-passed", **specification},
        "preflight_no_longer_matches",
    )
    prior._verify_source(expected, frozen)
    require((directory / "seed.pcm").read_bytes() == seed, "frozen_seed_changed")
    modal = importlib.import_module("modal")
    require(
        str(modal.__version__) == prior.SDK_VERSION, "registered_modal_sdk_required"
    )
    prior._journal(
        receipt, "attempt-started", first=True, source_digest=expected["digest"]
    )
    record = {"status": "failed", "ephemeral_context_exit_completed": False}
    try:
        app, endpoint = resources(modal, expected, plan, frozen)
        with app.run(detach=False):
            record["app_id"] = app.app_id
            prior._journal(receipt, "app-started", app_id=app.app_id)
            record.update(collect(endpoint.remote_gen(seed), directory, plan, expected))
        record["ephemeral_context_exit_completed"] = True
    except BaseException as error:
        record.update(
            status="failed",
            error_code=soak.failure_code(error, "memory_diagnostic_attempt_failed"),
            error_type=type(error).__name__,
        )
    record.update(
        specification=specification,
        qualified=False,
        diagnostic_only=True,
        claim_boundary="observational memory attribution; two repeated-input native sessions, not release qualification or a RAM policy change",
    )
    prior._write_result(output, record)
    prior._journal(
        receipt,
        "attempt-finished",
        status=record["status"],
        output_sha256=prior._sha(output.read_bytes()),
    )
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replay-id", required=True)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--preflight", action="store_true")
    mode.add_argument("--confirm-paid-gpu", action="store_true")
    args = parser.parse_args(argv)
    try:
        output = run(**vars(args))
        record = json.loads(output.read_text())
        print(output)
        return (
            0
            if (
                (args.preflight and record["status"] == "local-preflight-passed")
                or (
                    args.confirm_paid_gpu
                    and record["status"] == "completed"
                    and record.get("ephemeral_context_exit_completed") is True
                )
            )
            else 1
        )
    except Exception as error:
        print(
            "memory-diagnostic: " + soak.failure_code(error, "local_diagnostic_failed"),
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
