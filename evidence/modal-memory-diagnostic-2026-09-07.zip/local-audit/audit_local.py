"""Independent local receipt audit; never imports Modal or performs inference."""

from __future__ import annotations

import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path

DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[2]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return sha(
        json.dumps(
            value, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode()
    )


def check(condition, reason):
    if not condition:
        raise AssertionError(reason)


def word_score(observed, reference):
    observed = re.findall(r"\w+", observed.casefold())
    reference = re.findall(r"\w+", reference.casefold())
    previous = list(range(len(reference) + 1))
    for row, word in enumerate(observed, 1):
        current = [row]
        for column, target in enumerate(reference, 1):
            current.append(
                min(
                    current[-1] + 1,
                    previous[column] + 1,
                    previous[column - 1] + (word != target),
                )
            )
        previous = current
    return previous[-1], len(reference)


def audit():
    preflight = json.loads((DIRECTORY / "preflight.json").read_bytes())
    source, plan = preflight["source"], preflight["input"]
    check(canonical(source["files"]) == source["digest"], "source manifest digest")
    check(
        canonical(source["review_files_not_uploaded"]) == source["review_digest"],
        "review manifest digest",
    )
    for item in source["files"]:
        data = (DIRECTORY / "source" / item["path"]).read_bytes()
        check(
            len(data) == item["size_bytes"] and sha(data) == item["sha256"],
            "frozen " + item["path"],
        )
        check((ROOT / item["path"]).read_bytes() == data, "current " + item["path"])
    for item in source["review_files_not_uploaded"]:
        data = (ROOT / item["path"]).read_bytes()
        check(
            len(data) == item["size_bytes"] and sha(data) == item["sha256"],
            "review " + item["path"],
        )
    seed = (DIRECTORY / "seed.pcm").read_bytes()
    check(
        sha(seed) == plan["seed_sha256"] and len(seed) == plan["seed_samples"] * 2,
        "seed identity",
    )
    raw_result = (DIRECTORY / "diagnostic.json").read_bytes()
    result = json.loads(raw_result)
    expected_specification = {
        key: value for key, value in preflight.items() if key != "status"
    }
    check(result["specification"] == expected_specification, "preflight unchanged")
    raw = (DIRECTORY / "observations.jsonl").read_bytes()
    receipt = result["observation_receipt"]
    check(
        receipt
        == {"path": "observations.jsonl", "sha256": sha(raw), "size_bytes": len(raw)},
        "observation receipt",
    )
    check(raw.endswith(b"\n"), "partial last observation")
    observations = [json.loads(line) for line in raw.splitlines()]
    instance = observations[0]["instance_id"]
    for number, item in enumerate(observations, 1):
        check(item["sequence"] == number, "observation sequence")
        check(
            item["instance_id"] == instance
            and item["source_digest"] == source["digest"],
            "observation source/worker identity",
        )
    by_type = {
        kind: [item for item in observations if item["type"] == kind]
        for kind in {item["type"] for item in observations}
    }
    check(by_type["session_done"] == result["sessions"], "session summary parity")
    check(by_type["memory"] == result["snapshots"], "snapshot summary parity")
    check(
        by_type.get("operation", []) == result["operations"], "operation summary parity"
    )
    check(
        by_type["diagnostic_done"] == [result["terminal"]]
        and observations[-1] == result["terminal"],
        "single final diagnostic terminal",
    )
    check(
        result["status"] == result["terminal"]["status"]
        and result["status"] in ("completed", "failed"),
        "diagnostic status parity",
    )
    if result["status"] == "completed":
        check(
            result["terminal"]["sessions"] == 2
            and result["terminal"]["model_loads"] == 1,
            "one model/two sessions",
        )
    check(
        result["qualified"] is False and result["diagnostic_only"] is True,
        "claim boundary",
    )

    sys.path.insert(0, str(DIRECTORY / "source" / "src"))
    from whisper_runtime.adapters import StreamEventKind, TranscriptEvent
    from whisper_runtime.captions import CommittedTranscript
    from whisper_runtime.native_setup import MODEL_FINGERPRINT

    sessions = []
    previous_text = None
    for number, stage in enumerate(plan["phases"], 1):
        name = stage["phase"]
        starts = [item for item in by_type["session_started"] if item["phase"] == name]
        check(
            len(starts) == 1 and starts[0]["session_number"] == number,
            "session start identity",
        )
        done = next(item for item in by_type["session_done"] if item["phase"] == name)
        events = [item for item in by_type["event"] if item["phase"] == name]
        check(
            all(
                starts[0]["sequence"] < item["sequence"] < done["sequence"]
                for item in events
            ),
            "event lifecycle order",
        )
        projection = CommittedTranscript()
        for item in events:
            event = {**item["event"], "kind": StreamEventKind(item["event"]["kind"])}
            projection.accept(TranscriptEvent(**event))
        counts = Counter(item["event"]["kind"] for item in events)
        check(
            projection.final
            and projection.head == stage["sample_count"] == done["offered_samples"],
            "full final coverage",
        )
        check(
            counts["final"] == done["final_count"] == 1
            and events[-1]["event"]["kind"] == done["last_event_kind"] == "final",
            "FINAL exactly once",
        )
        check(
            len(events) == done["event_count"] and done["source_eof_received"] is True,
            "event count/EOF",
        )
        check(done["eof_chunks"] == (stage["sample_count"] + 319) // 320, "chunks")
        metrics, metadata = done["metrics"], done["metadata"]
        check(
            metrics["accepted_sha256"] == stage["sha256"] == plan["seed_sha256"],
            "accepted PCM identity",
        )
        check(
            metrics["accepted_samples"]
            == metrics["committed_samples"]
            == stage["sample_count"]
            and metrics["buffered_samples"] == 0,
            "metrics coverage",
        )
        check(
            metadata["source_digest"] == source["digest"]
            and metadata["instance_id"] == instance,
            "metadata identity",
        )
        check(
            metadata["model_loads"] == 1 and metadata["session_number"] == number,
            "model lifecycle",
        )
        check(
            metadata["model_initial_sha256"]
            == metadata["model_final_sha256"]
            == MODEL_FINGERPRINT
            and metadata["model_unchanged"] is True,
            "model fingerprint",
        )
        check(metadata["capacity_restored"] is True, "capacity cleanup")
        check(
            metadata["stream_config"] == plan["profile"]["stream_config"]
            and metadata["config_overrides"] == {}
            and done["profile"] == plan["profile"],
            "profile identity",
        )
        check(
            0 <= metadata["peak_buffered_samples"] <= metadata["max_buffer_samples"],
            "bounded buffer",
        )
        text = projection.render("txt")
        check(
            text == done["text"] and sha(text.encode()) == done["text_sha256"],
            "text projection/hash",
        )
        check(previous_text is None or text == previous_text, "repeat text parity")
        previous_text = text
        distance, words = word_score(text, plan["smoke_reference"])
        check(
            done["score"]["word_edit_distance"] == distance
            and done["score"]["reference_word_count"] == words
            and done["score"]["word_edit_rate"] == distance / words,
            "independent edit score",
        )
        check(distance / words <= plan["max_smoke_word_edit_rate"], "quality gate")
        sessions.append(
            {
                "phase": name,
                "elapsed_seconds": done["elapsed_seconds"],
                "events": dict(counts),
                "chunks": done["eof_chunks"],
                "samples": projection.head,
                "metrics": metrics,
                "text_sha256": done["text_sha256"],
                "export_sha256": {
                    format: sha(projection.render(format).encode())
                    for format in ("txt", "srt", "vtt")
                },
                "word_edits": distance,
                "reference_words": words,
                "cuda_allocated_before_bytes": metadata["allocated_before_bytes"],
                "cuda_allocated_after_bytes": metadata["allocated_after_bytes"],
            }
        )

    snapshots = result["snapshots"]
    check(
        len({item["phase"] for item in snapshots}) == len(snapshots),
        "unique memory stages",
    )
    check(
        set(plan["required_snapshots"]) <= {item["phase"] for item in snapshots},
        "required memory stages",
    )
    rows = []
    previous_statm_rss = None
    sampling_errors = []
    for item in snapshots:
        sample = item["sample"]
        sampling_errors.extend(
            {"phase": item["phase"], **error} for error in sample["errors"]
        )
        smaps = sample.get("smaps_rollup")
        fields = smaps["fields_bytes"] if smaps is not None else {}
        if smaps is None:
            check(
                any(error["component"] == "smaps_rollup" for error in sample["errors"]),
                "missing smaps must record measurement error",
            )
        statm_rss = sample["statm"]["rss_bytes"]
        rows.append(
            {
                "phase": item["phase"],
                "sequence": item["sequence"],
                "smaps_rss_bytes": fields.get("Rss"),
                "statm_rss_delta_from_previous_snapshot_bytes": None
                if previous_statm_rss is None
                else statm_rss - previous_statm_rss,
                "pss_bytes": fields.get("Pss"),
                "private_bytes": None if smaps is None else smaps["private_bytes"],
                "shared_bytes": None if smaps is None else smaps["shared_bytes"],
                "anonymous_bytes": fields.get("Anonymous"),
                "statm_rss_bytes": statm_rss,
                "threads": sample["threads"],
                "cuda": sample["cuda"],
                "environment": sample["environment"],
                "numba_config": sample["numba_config"],
            }
        )
        previous_statm_rss = statm_rss
    check(
        not sampling_errors or result["status"] == "failed",
        "measurement errors cannot pass diagnostic",
    )
    first = snapshots[0]
    check(
        first["phase"] == "before_native_imports"
        and not first["sample"]["torch_imported"]
        and not first["sample"]["whisper_imported"]
        and not first["sample"]["cuda"]["initialized"],
        "uninitialized baseline",
    )
    for name in ("session-1", "session-2"):
        closed = next(
            item for item in snapshots if item["phase"] == name + "_closed_gc"
        )
        done = next(item for item in result["sessions"] if item["phase"] == name)
        check(closed["sequence"] < done["sequence"], "closed snapshot before terminal")
    journal_raw = (DIRECTORY / "attempt.jsonl").read_bytes()
    journal = [json.loads(line) for line in journal_raw.splitlines()]
    check(
        [item["event"] for item in journal]
        == ["attempt-started", "app-started", "attempt-finished"],
        "journal lifecycle",
    )
    check(
        journal[0]["source_digest"] == source["digest"]
        and journal[1]["app_id"] == result["app_id"],
        "journal identity",
    )
    check(
        journal[-1]["output_sha256"] == sha(raw_result)
        and journal[-1]["status"] == result["status"],
        "journal result digest",
    )
    check(result["ephemeral_context_exit_completed"] is True, "app context exit")
    return {
        "audit_status": "passed",
        "audit_scope": "receipt/source integrity and completed-session transcript checks; not diagnostic qualification",
        "diagnostic_status": result["status"],
        "memory_measurements_complete": not sampling_errors,
        "memory_sampling_errors": sampling_errors,
        "diagnostic_only": True,
        "release_qualified": False,
        "source_files": len(source["files"]),
        "review_files": len(source["review_files_not_uploaded"]),
        "source_digest": source["digest"],
        "diagnostic_sha256": sha(raw_result),
        "observations_sha256": sha(raw),
        "observations_size_bytes": len(raw),
        "observation_count": len(observations),
        "observation_types": dict(Counter(item["type"] for item in observations)),
        "preflight_sha256": sha((DIRECTORY / "preflight.json").read_bytes()),
        "journal_sha256": sha(journal_raw),
        "app_id": result["app_id"],
        "ephemeral_context_exit_completed": True,
        "provider_zero_tasks_independently_queried": False,
        "sessions": sessions,
        "memory_stages": rows,
        "operations": result["operations"],
        "terminal": result["terminal"],
        "limits": [
            "Two repeated 46.55-second inputs, not endurance or general accuracy qualification.",
            "Memory counters observe stages; they do not identify individual mappings, allocation stacks, cgroup usage or provider billing.",
            "No remote calls or inference in this independent audit.",
            "Application context exit is reported locally; provider state must be established separately.",
        ],
    }


if __name__ == "__main__":
    report = audit()
    destination = DIRECTORY / "independent-local-audit.json"
    with destination.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(report, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
    print(json.dumps(report, indent=2, sort_keys=True))
