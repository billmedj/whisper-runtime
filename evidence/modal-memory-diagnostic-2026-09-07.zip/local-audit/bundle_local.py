"""Generate a portable audit and exact-byte evidence ZIP; no remote actions."""

from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

DIRECTORY = Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[2]
AUDIT_PATH = ROOT / "evidence/memory-attribution-audit-2026-09-07.json"
ZIP_PATH = ROOT / "evidence/modal-memory-diagnostic-2026-09-07.zip"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode()


def main():
    local = json.loads((DIRECTORY / "independent-local-audit.json").read_bytes())
    preflight = json.loads((DIRECTORY / "preflight.json").read_bytes())
    diagnostic = json.loads((DIRECTORY / "diagnostic.json").read_bytes())
    assert local["audit_status"] == "passed"
    assert local["diagnostic_status"] == diagnostic["status"] == "failed"
    assert diagnostic["terminal"]["error_code"] == "memory_sampling_incomplete"
    raw_names = (
        "preflight.json",
        "diagnostic.json",
        "observations.jsonl",
        "attempt.jsonl",
        "seed.pcm",
    )
    files = {"raw/" + name: (DIRECTORY / name).read_bytes() for name in raw_names}
    assert sha(files["raw/diagnostic.json"]) == local["diagnostic_sha256"]
    assert sha(files["raw/observations.jsonl"]) == local["observations_sha256"]
    assert sha(files["raw/preflight.json"]) == local["preflight_sha256"]
    assert sha(files["raw/attempt.jsonl"]) == local["journal_sha256"]
    for item in preflight["source"]["files"]:
        data = (DIRECTORY / "source" / item["path"]).read_bytes()
        assert len(data) == item["size_bytes"] and sha(data) == item["sha256"]
        files["source/" + item["path"]] = data
    for item in preflight["source"]["review_files_not_uploaded"]:
        data = (ROOT / item["path"]).read_bytes()
        assert len(data) == item["size_bytes"] and sha(data) == item["sha256"]
        files["review/" + item["path"]] = data
    public = {
        "schema_version": "local-memory-attribution-audit-v1",
        "date": "2026-09-07",
        "status": "failed",
        "failure_reason": "memory_sampling_incomplete",
        "receipt_source_and_transcript_audit": "passed",
        "diagnostic_only": True,
        "release_qualified": False,
        "approval_scope": "One T4 diagnostic, two identical source-paced 46.55-second sessions, 300-second function timeout; no retry or further paid run authorized by this audit.",
        "source": {
            "digest": local["source_digest"],
            "upload_files": local["source_files"],
            "upload_bytes": sum(
                item["size_bytes"] for item in preflight["source"]["files"]
            ),
            "review_files": local["review_files"],
            "review_digest": preflight["source"]["review_digest"],
            "policy": preflight["source"]["source_policy"],
            "all_frozen_upload_and_current_review_hashes_verified": True,
            "runtime_modules": sum(
                item["path"].startswith("src/") for item in preflight["source"]["files"]
            ),
        },
        "input": {
            "samples_per_session": preflight["input"]["seed_samples"],
            "sample_rate_hz": 16000,
            "sha256": preflight["input"]["seed_sha256"],
            "profile": preflight["input"]["profile"]["name"],
        },
        "observations": {
            "count": local["observation_count"],
            "types": local["observation_types"],
            "size_bytes": local["observations_size_bytes"],
            "sha256": local["observations_sha256"],
            "sequence_worker_and_source_identity_verified": True,
        },
        "sessions": local["sessions"],
        "text_and_caption_exports_identical_across_sessions": True,
        "elapsed_time_scope": "Session clocks start after owner.factory; model initialization, image construction and provider startup are excluded.",
        "native_identity_and_cleanup": {
            "model_loads": 1,
            "same_worker_both_sessions": True,
            "model_fingerprints_unchanged": True,
            "per_session_capacity_restored": True,
            "failure_handler_cleanup_verified": diagnostic["terminal"][
                "cleanup_verified"
            ],
            "failure_handler_limit": "False describes the later failure handler, entered after both streams had already been closed and released; it does not replace the successful per-session capacity-restored receipts.",
            "ephemeral_context_exit_completed": local[
                "ephemeral_context_exit_completed"
            ],
        },
        "memory": {
            "measurements_complete": False,
            "missing_component": "smaps_rollup",
            "sampling_error": "FileNotFoundError",
            "affected_snapshots": len(local["memory_sampling_errors"]),
            "stages": local["memory_stages"],
            "dtw_calls": diagnostic["terminal"]["dtw_calls"],
            "first_dtw_cuda_wall_ns": local["operations"][0]["wall_ns"],
            "registered_release_rss_ceiling_bytes_unchanged": preflight["input"][
                "release_memory_gates_unchanged"
            ]["rss_ceiling_bytes"],
        },
        "app_lifecycle": {
            "app_id": diagnostic["app_id"],
            "client_exit_code_reported_by_parent": 1,
            "provider_state_reported_by_parent": "stopped",
            "provider_active_tasks_reported_by_parent": 0,
            "provider_reported_stopped_at_utc": "2026-09-07T04:27:09Z",
            "provider_reported_stopped_at_local": "2026-09-07T12:27:09+08:00",
            "read_only_query_observation_end_utc": "2026-09-07T04:27:47.2390229Z",
            "verification_source": "Parent agent read-only Modal app-list result; not independently queried by this local audit and not a raw provider receipt in this bundle.",
        },
        "evidence_bundle": ZIP_PATH.relative_to(ROOT).as_posix(),
        "raw_receipts": {
            name: {"size_bytes": len(data), "sha256": sha(data)}
            for name, data in files.items()
            if name.startswith("raw/")
        },
        "interpretation_limits": [
            "The large statm increase is already present after Torch import, before model loading or transcription; this locates an observed stage, not an allocation cause.",
            "Another increase precedes the first dtw_cuda call; the measured first call itself adds 23,646,208 statm bytes. No dtw_cpu calls were observed.",
            "Closed-session statm grows by 4,767,744 bytes across the second short session, with unchanged terminal CUDA allocated/reserved counters; two sessions cannot prove absence of leaks.",
            "smaps_rollup/PSS/private/shared accounting is unavailable. No per-mapping data, allocation stacks, cgroup memory.current, provider host-memory measurement or billed usage was captured.",
            "Modal/gVisor proc counters are documented approximations. That limitation does not establish that the observed excess is spurious or invalidate the earlier failed RSS gate.",
            "This failed diagnostic does not qualify four-hour endurance, clean installation, physical capture or a stable release. No memory gate, allocator setting, runtime source or weights were changed.",
        ],
        "accounting_reference_verified_by_parent": "https://gvisor.dev/docs/architecture_guide/resources/",
    }
    public_bytes = encoded(public)
    with AUDIT_PATH.open("xb") as handle:
        handle.write(public_bytes)
    files["audit/memory-attribution-audit-2026-09-07.json"] = public_bytes
    for name in ("independent-local-audit.json", "audit_local.py", "bundle_local.py"):
        files["local-audit/" + name] = (DIRECTORY / name).read_bytes()
    manifest = {
        "schema_version": "exact-byte-evidence-bundle-v1",
        "description": "Failed single T4 memory attribution diagnostic; original raw receipts and all 51 uploaded / 4 review source files.",
        "files": [
            {"path": name, "size_bytes": len(data), "sha256": sha(data)}
            for name, data in sorted(files.items())
        ],
        "audit_script_execution_scope": "The included local audit was executed in the recorded checkout; it is not a standalone extracted-bundle runner. Manifest hashes provide portable byte verification.",
        "self_hash_omitted": True,
    }
    files["manifest.json"] = encoded(manifest)
    with zipfile.ZipFile(
        ZIP_PATH, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 9, 7, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, data, compresslevel=9)
    with zipfile.ZipFile(ZIP_PATH) as archive:
        assert set(archive.namelist()) == set(files)
        assert all(archive.read(name) == data for name, data in files.items())
    summary = {
        "evidence_bundle": ZIP_PATH.relative_to(ROOT).as_posix(),
        "size_bytes": ZIP_PATH.stat().st_size,
        "sha256": sha(ZIP_PATH.read_bytes()),
        "payload_files": len(files) - 1,
        "manifest_files": 1,
        "portable_audit_sha256": sha(public_bytes),
    }
    with (DIRECTORY / "evidence-bundle-summary.json").open("xb") as handle:
        handle.write(encoded(summary))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
