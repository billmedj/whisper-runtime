"""Local capacity-smoke receipt audit; no Modal import, network or inference.

Prints JSON; --output also exclusively creates the same report. Exit 0 means a fully audited completed short smoke, not release
qualification. Exit 1 also permits inspection of intact failed/partial receipts.
Review-only files are checked against the frozen review directory when present,
otherwise this repository; uploaded files against the frozen source directory.
Neither guest receipts nor this audit attest that
the provider actually enforced the submitted memory limit.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import sys
from collections import Counter
from dataclasses import asdict
from datetime import datetime
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[2]
sys.dont_write_bytecode = True
MODE = "provider-capacity-smoke-v1"
SEED_SHA = "b8902a2cfd5c45b8a17d6b489f6ddc752cf76d7b620efa27ec6e173ea6e2f826"
MODEL_SHA = "sha256:8041a80119a588f542472da35e97d0372fce1d9709ed9874475e9c03deac5de6"
CUDA_POLICY = {
    "terminal_allocated_delta_bytes": 0,
    "reserved_growth_bytes": 256 * 1024**2,
    "reserved_ceiling_bytes": 2048 * 1024**2,
}
SNAPSHOTS = (
    "before_native_imports",
    "after_torch_import",
    "after_native_imports",
    "after_model_load",
    "after_model_fingerprint",
    "session-1_closed_gc",
    "session-2_closed_gc",
)


def check(condition, reason):
    if not condition:
        raise AssertionError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return sha(
        json.dumps(
            value, sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode()
    )


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            check(key not in result, "duplicate JSON key")
            result[key] = value
        return result

    def invalid(value):
        raise AssertionError("non-finite JSON number")

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)


def read(path, limit=16 * 1024**2):
    check(path.stat().st_size <= limit, "artifact size limit: " + path.name)
    return path.read_bytes()


def jsonl(raw):
    check(not raw or raw.endswith(b"\n"), "partial last JSONL record")
    return [parse(line) for line in raw.splitlines()]


def manifest(items, digest, root):
    check(canonical(items) == digest, "manifest digest")
    names = [item["path"] for item in items]
    check(names == sorted(set(names)), "manifest order/duplicates")
    for item in items:
        relative = PurePosixPath(item["path"])
        check(
            not relative.is_absolute()
            and ".." not in relative.parts
            and "\\" not in item["path"]
            and ":" not in item["path"],
            "unsafe manifest path",
        )
        path = root.joinpath(*relative.parts).resolve()
        check(path.is_relative_to(root.resolve()), "manifest path redirect")
        data = read(path)
        check(
            len(data) == item["size_bytes"] and sha(data) == item["sha256"],
            "manifest bytes: " + item["path"],
        )


def resource_definition(frozen):
    """Check the frozen decorator's selected tuple without executing its code."""
    tree = ast.parse(read(frozen / "infra/modal_memory_diagnostic.py").decode())
    resources = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "resources"
    )
    endpoint = next(
        node
        for node in resources.body
        if isinstance(node, ast.FunctionDef) and node.name == "endpoint"
    )
    calls = [
        node
        for node in endpoint.decorator_list
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == "function"
    ]
    check(len(calls) == 1, "single frozen function decorator")
    keywords = {item.arg: item.value for item in calls[0].keywords}
    memory = keywords["memory"]
    check(
        isinstance(memory, ast.IfExp)
        and ast.dump(memory.test)
        == ast.dump(ast.parse("capacity_mode(plan)", mode="eval").body)
        and ast.literal_eval(memory.body) == (4096, 4096),
        "frozen memory maximum",
    )
    for name, expected in {
        "gpu": "T4",
        "cpu": 2,
        "max_containers": 1,
        "min_containers": 0,
        "buffer_containers": 0,
        "single_use_containers": True,
        "block_network": True,
    }.items():
        check(ast.literal_eval(keywords[name]) == expected, "frozen resource: " + name)
    check("retries" not in keywords, "generator retry policy must be absent")


def word_score(observed, reference):
    observed, reference = (
        re.findall(r"\w+", text.casefold()) for text in (observed, reference)
    )
    previous = list(range(len(reference) + 1))
    for row, word in enumerate(observed, 1):
        current = [row]
        for column, target in enumerate(reference, 1):
            current.append(
                min(
                    current[-1] + 1,
                    previous[column] + 1,
                    previous[column - 1] + (word != target),
                )
            )
        previous = current
    check(bool(reference), "empty reference")
    return previous[-1], len(reference)


def cuda_valid(sample, baseline=None):
    value = sample.get("cuda", {})
    fields = (
        "allocated_bytes",
        "reserved_bytes",
        "peak_allocated_bytes",
        "peak_reserved_bytes",
    )
    return (
        isinstance(value, dict)
        and value.get("initialized") is True
        and all(type(value.get(key)) is int and value[key] >= 0 for key in fields)
        and value["allocated_bytes"] <= value["reserved_bytes"]
        and value["allocated_bytes"] <= value["peak_allocated_bytes"]
        and value["reserved_bytes"] <= value["peak_reserved_bytes"]
        and value["reserved_bytes"] <= CUDA_POLICY["reserved_ceiling_bytes"]
        and (
            baseline is None
            or (
                value["allocated_bytes"] == baseline["allocated_bytes"]
                and value["reserved_bytes"]
                <= baseline["reserved_bytes"] + CUDA_POLICY["reserved_growth_bytes"]
            )
        )
    )


def audit(directory):
    directory = directory.resolve()
    raw_preflight = read(directory / "preflight.json")
    preflight = parse(raw_preflight)
    source, plan, budget = (preflight[key] for key in ("source", "input", "budget"))
    check(
        preflight["status"] == "local-preflight-passed"
        and preflight["qualified"] is False,
        "preflight status/claim",
    )
    check(
        all(value["mode"] == MODE for value in (preflight, plan, budget)),
        "registered capacity mode",
    )
    frozen = directory / "source"
    manifest(source["files"], source["digest"], frozen)
    review = directory / "review" if (directory / "review").is_dir() else ROOT
    manifest(source["review_files_not_uploaded"], source["review_digest"], review)
    resource_definition(frozen)
    contract = plan["submitted_resource_contract"]
    check(contract == budget["submitted_resource_contract"], "resource contract parity")
    for key, value in {
        "mode": MODE,
        "sdk_version": "1.5.5",
        "gpu": "T4",
        "memory_request_mib": 4096,
        "memory_limit_mib": 4096,
        "maximum_containers": 1,
        "timeout_seconds": 300,
        "guest_attests_provider_enforcement": False,
    }.items():
        check(contract[key] == value, "registered resource: " + key)
    check(
        budget["configured_retries"] == 0
        and budget["sdk_retry_policy"] is None
        and budget["minimum_gpu_containers"] == budget["buffer_containers"] == 0
        and budget["maximum_gpu_containers"] == 1,
        "no retry/extra container",
    )
    seed = read(directory / "seed.pcm", 2 * 1024**2)
    check(
        sha(seed) == plan["seed_sha256"] == SEED_SHA
        and len(seed) == plan["seed_samples"] * 2 == 1489600,
        "registered seed identity",
    )
    check(
        plan["phases"]
        == [
            {
                "phase": name,
                "sample_count": 744800,
                "sha256": SEED_SHA,
                "timeout_seconds": 190,
            }
            for name in ("session-1", "session-2")
        ],
        "two registered short sessions",
    )
    check(
        plan["capacity_cuda_policy"] == CUDA_POLICY
        and plan["max_smoke_word_edit_rate"] == 0.1
        and plan["outer_seconds"] == 300,
        "fixed CUDA/quality/time policies",
    )
    check(
        tuple(plan["required_snapshots"]) == SNAPSHOTS
        and plan["guest_memory_is_optional"] is True
        and plan["guest_rss_is_physical_capacity_gate"] is False
        and plan["release_memory_gates_unchanged"]["rss_ceiling_bytes"]
        == 3584 * 1024**2,
        "original RSS gate/measurement boundary",
    )
    sys.path.insert(0, str(frozen / "src"))
    import whisper_runtime.captions as captions
    from whisper_runtime.adapters import StreamEventKind, TranscriptEvent
    from whisper_runtime.captions import CommittedTranscript
    from whisper_runtime.profiles import get_profile

    check(
        Path(captions.__file__).resolve().is_relative_to(frozen.resolve()),
        "use frozen caption implementation",
    )
    check(
        plan["profile"] == asdict(get_profile("conservative-v1")),
        "frozen conservative profile",
    )
    report = {
        "audit_status": "preflight-verified",
        "mode": MODE,
        "capacity_smoke_passed": False,
        "release_qualified": False,
        "provider_enforcement_independently_verified": False,
        "host_physical_memory_measured": False,
        "source_digest": source["digest"],
        "review_digest": source["review_digest"],
        "source_files": len(source["files"]),
        "review_files": len(source["review_files_not_uploaded"]),
        "review_bytes_basis": "frozen" if review != ROOT else "current_repository",
        "source_bytes": sum(item["size_bytes"] for item in source["files"]),
        "preflight_sha256": sha(raw_preflight),
        "seed_sha256": sha(seed),
        "submitted_resource_contract": contract,
        "sessions": [],
        "acceptance_failures": [],
    }
    if not (directory / "diagnostic.json").exists():
        report["acceptance_failures"].append("no_final_record")
        return report
    raw_result = read(directory / "diagnostic.json")
    result = parse(raw_result)
    check(
        result["specification"]
        == {key: value for key, value in preflight.items() if key != "status"},
        "result specification equals preflight",
    )
    check(
        result["mode"] == MODE
        and result["qualified"] is False
        and result["diagnostic_only"] is False
        and result["status"] in ("completed", "failed"),
        "result mode/status/claim",
    )
    journal_raw = read(directory / "attempt.jsonl", 65536)
    journal = jsonl(journal_raw)
    events = [item["event"] for item in journal]
    check(
        events
        in (
            ["attempt-started", "app-started", "attempt-finished"],
            ["attempt-started", "attempt-finished"],
        ),
        "journal lifecycle",
    )
    check(
        journal[0]["source_digest"] == source["digest"]
        and journal[-1]["output_sha256"] == sha(raw_result)
        and journal[-1]["status"] == result["status"],
        "journal source/result checksum",
    )
    times = [datetime.fromisoformat(item["at"]) for item in journal]
    check(times == sorted(times), "journal chronological order")
    if "app-started" in events:
        check(
            journal[1]["app_id"] == result["app_id"] and bool(result["app_id"]),
            "journal app identity",
        )
    else:
        check(
            not result.get("app_id") and result["status"] == "failed", "no app started"
        )
    raw = (
        read(directory / "observations.jsonl", 8 * 1024**2)
        if (directory / "observations.jsonl").exists()
        else b""
    )
    rows = jsonl(raw)
    receipt = {"path": "observations.jsonl", "sha256": sha(raw), "size_bytes": len(raw)}
    if "observation_receipt" in result:
        check(result["observation_receipt"] == receipt, "observation checksum/size")
    else:
        report["acceptance_failures"].append("observation_receipt_unavailable")
    instance = rows[0]["instance_id"] if rows else None
    check(not rows or bool(instance), "nonempty worker identity")
    groups = {}
    active = projection = None
    session_number = 0
    session_events = []
    completed = []
    snapshots = {}
    baseline = previous_text = previous_exports = None
    terminal = None
    capability = None
    for number, item in enumerate(rows, 1):
        check(len(json.dumps(item).encode()) <= 512 * 1024, "observation message size")
        check(
            item["sequence"] == number
            and item["instance_id"] == instance
            and item["source_digest"] == source["digest"],
            "observation sequence/source/single worker",
        )
        check(terminal is None, "message after terminal")
        kind = item["type"]
        groups.setdefault(kind, []).append(item)
        if kind == "resource_capabilities":
            check(
                number == 1
                and item["submitted_resource_contract"] == contract
                and item["before_native_imports"] is True
                and item["torch_imported"] is False
                and item["whisper_imported"] is False
                and item["guest_attests_provider_enforcement"] is False
                and item["detailed_smaps_sampled"] is False
                and item["required_terminal_cuda_counters"] is True,
                "pre-import capability receipt",
            )
            capability = item
        elif kind == "memory":
            check(item["phase"] not in snapshots, "duplicate snapshot")
            snapshots[item["phase"]] = item
        elif kind == "session_started":
            check(active is None and session_number < 2, "extra/overlapping session")
            session_number += 1
            check(
                item["session_number"] == session_number
                and item["phase"] == plan["phases"][session_number - 1]["phase"],
                "session order",
            )
            active, projection, session_events = (
                item["phase"],
                CommittedTranscript(),
                [],
            )
        elif kind == "event":
            check(
                active == item["phase"] and projection is not None,
                "event outside session",
            )
            event = {**item["event"], "kind": StreamEventKind(item["event"]["kind"])}
            projection.accept(TranscriptEvent(**event))
            session_events.append(item["event"])
            check(len(session_events) <= 10000, "session event limit")
        elif kind == "session_done":
            check(
                active == item["phase"] and projection is not None,
                "unexpected session terminal",
            )
            counts = Counter(event["kind"] for event in session_events)
            check(
                item["status"] == "completed"
                and projection.final
                and projection.head == item["offered_samples"] == 744800,
                "full completed coverage",
            )
            check(
                counts["final"] == item["final_count"] == 1
                and session_events[-1]["kind"] == item["last_event_kind"] == "final"
                and len(session_events) == item["event_count"]
                and item["source_eof_received"] is True,
                "single FINAL/event count/EOF",
            )
            metrics, metadata = item["metrics"], item["metadata"]
            check(
                metrics["accepted_sha256"] == SEED_SHA
                and metrics["accepted_samples"]
                == metrics["committed_samples"]
                == 744800
                and metrics["buffered_samples"] == 0
                and metrics["accepted_chunks"] == item["eof_chunks"] == 2328,
                "PCM metrics/hash/chunks",
            )
            check(
                metadata["instance_id"] == instance
                and metadata["source_digest"] == source["digest"]
                and metadata["session_number"] == session_number
                and metadata["model_loads"] == 1
                and metadata["model_initial_sha256"]
                == metadata["model_final_sha256"]
                == MODEL_SHA
                and metadata["model_unchanged"] is True
                and metadata["capacity_restored"] is True,
                "native identity/capacity return",
            )
            check(
                item["profile"] == plan["profile"]
                and metadata["config_overrides"] == {}
                and metadata["stream_config"] == plan["profile"]["stream_config"]
                and 0
                <= metadata["peak_buffered_samples"]
                <= metadata["max_buffer_samples"]
                == plan["profile"]["stream_config"]["max_buffer_ms"] * 16,
                "profile/buffer bound",
            )
            check(46.55 <= item["elapsed_seconds"] <= 190, "source-paced session time")
            text = projection.render("txt")
            check(
                text == item["text"]
                and len(text) <= 65536
                and sha(text.encode()) == item["text_sha256"]
                and (previous_text is None or previous_text == text),
                "text projection/hash/repeat parity",
            )
            edits, words = word_score(text, plan["smoke_reference"])
            check(
                item["score"]["word_edit_distance"] == edits
                and item["score"]["reference_word_count"] == words
                and item["score"]["word_edit_rate"] == edits / words <= 0.1,
                "independent word-edit score",
            )
            closed = snapshots.get(active + "_closed_gc")
            check(
                closed is not None
                and closed["sequence"] < number
                and cuda_valid(closed["sample"], baseline),
                "closed CUDA baseline/plateau",
            )
            cuda = closed["sample"]["cuda"]
            check(
                cuda["allocated_bytes"] == metadata["allocated_after_bytes"],
                "CUDA receipt parity",
            )
            if baseline is not None:
                check(
                    metadata["allocated_before_bytes"] == baseline["allocated_bytes"],
                    "second CUDA admission",
                )
            baseline = baseline or cuda
            exports = {
                fmt: sha(projection.render(fmt).encode())
                for fmt in ("txt", "srt", "vtt")
            }
            check(
                item["export_sha256"] == exports
                and (previous_exports is None or previous_exports == exports),
                "caption export hashes/parity",
            )
            previous_exports = exports
            completed.append(item)
            report["sessions"].append(
                {
                    "phase": active,
                    "samples": projection.head,
                    "events": dict(counts),
                    "elapsed_seconds": item["elapsed_seconds"],
                    "word_edits": edits,
                    "reference_words": words,
                    "cuda": cuda,
                    "export_sha256": exports,
                }
            )
            previous_text, active, projection = text, None, None
        elif kind == "diagnostic_done":
            check(
                item["status"] in ("failed", "completed")
                and item["qualified"] is False,
                "terminal status/claim",
            )
            terminal = item
            if item["status"] == "completed":
                check(
                    active is None
                    and len(completed) == item["sessions"] == 2
                    and item["model_loads"] == 1,
                    "completed terminal lifecycle",
                )
        else:
            check(kind == "operation", "unknown observation")
    for key, kind in (
        ("sessions", "session_done"),
        ("snapshots", "memory"),
        ("operations", "operation"),
    ):
        if key in result:
            check(result[key] == groups.get(kind, []), "summary parity: " + key)
    if "terminal" in result:
        check(result["terminal"] == terminal, "terminal summary parity")
    if "resource_contract_receipt" in result:
        check(
            result["resource_contract_receipt"] == capability, "resource summary parity"
        )
    failures = report["acceptance_failures"]
    for condition, reason in (
        (result["status"] == "completed", "attempt_failed"),
        (
            result.get("ephemeral_context_exit_completed") is True,
            "context_exit_unverified",
        ),
        (
            terminal is not None and terminal["status"] == "completed",
            "completed_terminal_missing",
        ),
        (capability is not None, "resource_capability_missing"),
        (len(completed) == 2, "two_completed_sessions_missing"),
        (set(SNAPSHOTS) <= snapshots.keys(), "required_snapshot_missing"),
    ):
        if not condition:
            failures.append(reason)
    first = snapshots.get("before_native_imports", {}).get("sample", {})
    if not (
        first.get("torch_imported") is False
        and first.get("whisper_imported") is False
        and first.get("cuda", {}).get("initialized") is False
    ):
        failures.append("uninitialized_baseline_missing")
    errors = [
        {"phase": name, **error}
        for name, row in snapshots.items()
        for error in row["sample"].get("errors", [])
    ]
    optional = {"detailed_memory", "statm", "threads", "torch_threads"}
    if any(error.get("component") not in optional for error in errors):
        failures.append("required_sampling_failure")
    if result["status"] == "completed":
        check(
            all(
                key in result
                for key in (
                    "sessions",
                    "snapshots",
                    "operations",
                    "terminal",
                    "resource_contract_receipt",
                    "observation_receipt",
                )
            ),
            "complete result summaries required",
        )
        check(
            not failures,
            "completed result fails independent acceptance: " + ",".join(failures),
        )
    report.update(
        audit_status="passed" if not failures else "failed-run-inspected",
        attempt_status=result["status"],
        capacity_smoke_passed=not failures,
        failure_code=result.get("error_code") or (terminal or {}).get("error_code"),
        app_id=result.get("app_id"),
        ephemeral_context_exit_completed=result.get("ephemeral_context_exit_completed"),
        diagnostic_sha256=sha(raw_result),
        journal_sha256=sha(journal_raw),
        observation_receipt=receipt,
        observation_count=len(rows),
        observation_types={kind: len(items) for kind, items in groups.items()},
        memory_sampling_errors=errors,
        terminal=terminal,
        limitations=[
            "Short repeated-input smoke, not endurance or release qualification.",
            "Submitted provider limit is verified, not independent host enforcement or physical RSS.",
            "Historical 3.5 GiB RSS gate remains unchanged and failed.",
            "Context exit is a local receipt; provider stopped/zero-task state needs separate evidence.",
        ],
    )
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", required=True, type=Path)
    parser.add_argument("--output", type=Path, help="exclusively create a JSON report; never overwrite")
    args = parser.parse_args()
    try:
        report = audit(args.directory)
    except (
        AssertionError,
        KeyError,
        ValueError,
        TypeError,
        OSError,
        StopIteration,
    ) as error:
        report = {
            "audit_status": "failed",
            "capacity_smoke_passed": False,
            "release_qualified": False,
            "error_type": type(error).__name__,
            "error": str(error),
        }
    encoded = json.dumps(report, indent=2, sort_keys=True, allow_nan=False) + "\n"
    if args.output is not None:
        with args.output.open("x", encoding="utf-8", newline="\n") as handle:
            handle.write(encoded)
    print(encoded, end="")
    return 0 if report["capacity_smoke_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
