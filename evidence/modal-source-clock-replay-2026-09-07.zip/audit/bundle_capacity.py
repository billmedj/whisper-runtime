"""Exclusive-create capacity evidence ZIP; reread verification uses archive bytes only.

No audit, inference or provider action is performed. Recorded status is preserved.
Use --verify-only --output FILE.zip to verify an existing archive without sources.
"""

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath


def check(value, reason):
    if not value:
        raise ValueError(reason)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode()


def verify(path):
    """No checkout/input directory access; integrity, not a qualification claim."""
    with zipfile.ZipFile(path) as archive:
        entries = json.loads(archive.read("manifest.json"))["files"]
        names = archive.namelist()
        check(
            len(names) == len(set(names)) == len(entries) + 1, "duplicate ZIP entries"
        )
        check(
            set(names) == {item["path"] for item in entries} | {"manifest.json"},
            "ZIP inventory",
        )
        for item in entries:
            data = archive.read(item["path"])
            check(
                len(data) == item["size_bytes"] and sha(data) == item["sha256"],
                "ZIP member checksum",
            )
        preflight = json.loads(archive.read("raw/preflight.json"))
        source = preflight["source"]
        for prefix, field, digest in (
            ("source", "files", "digest"),
            ("review", "review_files_not_uploaded", "review_digest"),
        ):
            canonical = json.dumps(
                source[field], sort_keys=True, separators=(",", ":"), allow_nan=False
            ).encode()
            check(sha(canonical) == source[digest], "frozen manifest digest")
            for item in source[field]:
                data = archive.read(prefix + "/" + item["path"])
                check(
                    len(data) == item["size_bytes"] and sha(data) == item["sha256"],
                    "frozen manifest bytes",
                )
        audit = json.loads(archive.read("audit/independent-audit.json"))
        result_bytes = archive.read("raw/diagnostic.json")
        result = json.loads(result_bytes)
        for name, key in (
            ("preflight.json", "preflight_sha256"),
            ("diagnostic.json", "diagnostic_sha256"),
            ("attempt.jsonl", "journal_sha256"),
            ("seed.pcm", "seed_sha256"),
        ):
            check(sha(archive.read("raw/" + name)) == audit[key], "audit/raw binding")
        observations = archive.read("raw/observations.jsonl")
        check(
            audit["observation_receipt"]
            == {
                "path": "observations.jsonl",
                "sha256": sha(observations),
                "size_bytes": len(observations),
            },
            "audit/log binding",
        )
        journal = [
            json.loads(line) for line in archive.read("raw/attempt.jsonl").splitlines()
        ]
        check(
            journal[-1]["output_sha256"] == sha(result_bytes), "journal/result binding"
        )
        check(
            audit["source_digest"] == source["digest"]
            and audit["attempt_status"] == result["status"],
            "audit/source/status binding",
        )
        stopped = json.loads(archive.read("raw/provider-stop.json"))
        check(
            stopped["app_id"] == result["app_id"]
            and stopped["state"] == "stopped"
            and stopped["tasks"] in (0, "0"),
            "provider stop receipt identity/state",
        )
    return {
        "archive_only_verification": "passed",
        "sha256": sha(path.read_bytes()),
        "size_bytes": path.stat().st_size,
        "payload_files": len(entries),
        "attempt_status": result["status"],
        "audit_status": audit["audit_status"],
        "provider_stop_receipt_state": stopped["state"],
        "provider_stop_receipt_tasks": stopped["tasks"],
        "capacity_smoke_passed": audit["capacity_smoke_passed"],
        "release_qualified": audit["release_qualified"],
    }


def bundle(directory, output):
    preflight = json.loads((directory / "preflight.json").read_bytes())
    files = {
        "raw/" + name: (directory / name).read_bytes()
        for name in (
            "preflight.json",
            "diagnostic.json",
            "observations.jsonl",
            "attempt.jsonl",
            "seed.pcm",
            "provider-stop.json",
        )
    }
    for prefix, field in (("source", "files"), ("review", "review_files_not_uploaded")):
        for item in preflight["source"][field]:
            relative = PurePosixPath(item["path"])
            check(
                not relative.is_absolute()
                and ".." not in relative.parts
                and "\\" not in str(relative)
                and ":" not in str(relative),
                "unsafe source path",
            )
            file = (directory / prefix).joinpath(*relative.parts).resolve()
            check(
                file.is_relative_to((directory / prefix).resolve()),
                "source path redirect",
            )
            data = file.read_bytes()
            check(
                len(data) == item["size_bytes"] and sha(data) == item["sha256"],
                "frozen source changed",
            )
            files[prefix + "/" + item["path"]] = data
    files["audit/independent-audit.json"] = (
        directory / "independent-audit.json"
    ).read_bytes()
    for name in ("audit_capacity.py", "bundle_capacity.py"):
        files["audit/" + name] = (Path(__file__).parent / name).read_bytes()
    files["manifest.json"] = encoded(
        {
            "schema_version": "exact-byte-capacity-evidence-v1",
            "self_hash_omitted": True,
            "files": [
                {"path": name, "size_bytes": len(data), "sha256": sha(data)}
                for name, data in sorted(files.items())
            ],
        }
    )
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(files.items()):
            archive.writestr(name, data)
    return verify(output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    check(
        args.verify_only or args.directory is not None,
        "--directory required to create a bundle",
    )
    print(
        encoded(
            verify(args.output)
            if args.verify_only
            else bundle(args.directory, args.output)
        ).decode(),
        end="",
    )
