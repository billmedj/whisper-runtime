"""Deterministic local receipt mutations; no native imports, network or GPU."""

import copy
import json
import math
import subprocess
import sys
import unittest
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

import audit_capacity as audit

HERE = Path(__file__).resolve().parent


def frame(sequence, late):
    end = min((sequence + 1) * 320, 744800)
    due = end / 16000
    return {
        "sequence": sequence,
        "start_sample": sequence * 320,
        "end_sample": end,
        "due_elapsed_seconds": due,
        "wake_elapsed_seconds": due + late,
        "wake_lateness_seconds": late,
    }


def clock(*, frames=2, failed=False):
    last = frame(frames if failed else frames - 1, 0.251 if failed else 0.002)
    return {
        "schema_version": "source-clock-v2",
        "clock": "time.monotonic",
        "origin_monotonic_seconds": 100.0,
        "max_wake_lateness_seconds": 0.251 if failed else 0.005,
        "max_wake_frame": copy.deepcopy(last) if failed else frame(0, 0.005),
        "max_yield_resume_seconds": 0.001 if frames else 0.0,
        "max_yield_resume_interval": {
            "sequence": 0,
            "start_sample": 0,
            "end_sample": 320,
            "yield_elapsed_seconds": 0.026,
            "resume_elapsed_seconds": 0.027,
            "gap_seconds": 0.001,
        }
        if frames
        else None,
        "offered_frames": frames,
        "offered_samples": min(frames * 320, 744800),
        "last_yield_sequence": frames - 1 if frames else None,
        "last_yield_end_sample": min(frames * 320, 744800) if frames else None,
        "last_attempt": last,
        "failed_frame": copy.deepcopy(last) if failed else None,
    }


def operation():
    return {
        "name": "dtw_cuda",
        "session": "session-1",
        "clock": "time.monotonic",
        "start_monotonic_seconds": 100.021,
        "end_monotonic_seconds": 100.027,
        "wall_ns": 5_000_000,
    }


class ClockTests(unittest.TestCase):
    def test_valid_partial_complete_and_failed_v2(self):
        audit.source_clock(clock(), completed=False, expected_version="source-clock-v2")
        audit.source_clock(clock(frames=2328), completed=True, elapsed_limit=47.1)
        for frames in (0, 2):
            audit.source_clock(
                clock(frames=frames, failed=True), completed=False, source_late=True
            )

    def test_v2_mutations_fail(self):
        mutations = (
            (("schema_version",), "source-clock-v1"),
            (("clock",), "time.perf_counter"),
            (("origin_monotonic_seconds",), float("nan")),
            (("origin_monotonic_seconds",), -1),
            (("last_yield_sequence",), True),
            (("max_wake_frame",), None),
            (("max_wake_frame", "sequence"), 2),
            (("max_wake_frame", "start_sample"), 1),
            (("max_wake_frame", "due_elapsed_seconds"), 0.04),
            (("max_wake_frame", "wake_lateness_seconds"), 0.007),
            (("max_wake_lateness_seconds",), 0.006),
            (("max_yield_resume_interval",), None),
            (("max_yield_resume_interval", "sequence"), 2),
            (("max_yield_resume_interval", "yield_elapsed_seconds"), 0.001),
            (("max_yield_resume_interval", "resume_elapsed_seconds"), 0.025),
            (("max_yield_resume_interval", "gap_seconds"), 0.002),
            (("max_yield_resume_seconds",), 0.002),
        )
        for path, invalid in mutations:
            with self.subTest(path=path, invalid=invalid):
                value = clock()
                parent = value
                for key in path[:-1]:
                    parent = parent[key]
                parent[path[-1]] = invalid
                with self.assertRaises((AssertionError, ValueError)):
                    audit.source_clock(
                        value, completed=False, expected_version="source-clock-v2"
                    )

    def test_frozen_schema_forbids_downgrade(self):
        value = clock()
        for key in (
            "clock",
            "origin_monotonic_seconds",
            "max_wake_frame",
            "max_yield_resume_interval",
        ):
            value.pop(key)
        value["schema_version"] = "source-clock-v1"
        audit.source_clock(value, completed=False, expected_version="source-clock-v1")
        with self.assertRaisesRegex(AssertionError, "frozen source"):
            audit.source_clock(
                value, completed=False, expected_version="source-clock-v2"
            )

    def test_completed_coverage_and_deadline_still_fail_closed(self):
        for value in (clock(), clock(failed=True)):
            with self.assertRaises(AssertionError):
                audit.source_clock(value, completed=True)
        with self.assertRaisesRegex(AssertionError, "session terminal"):
            audit.source_clock(clock(frames=2328), completed=True, elapsed_limit=46.55)

    def test_exact_lateness_threshold_is_unchanged(self):
        value = clock(frames=2328)
        maximum = frame(0, 0.25)
        value.update(max_wake_frame=maximum, max_wake_lateness_seconds=0.25)
        # Place the interval later than this maximum's wake.
        value["max_yield_resume_interval"].update(
            yield_elapsed_seconds=0.271, resume_elapsed_seconds=0.272
        )
        audit.source_clock(value, completed=True)
        maximum["wake_elapsed_seconds"] += 0.000001
        maximum["wake_lateness_seconds"] += 0.000001
        value["max_wake_lateness_seconds"] += 0.000001
        with self.assertRaises(AssertionError):
            audit.source_clock(value, completed=True)

    def test_failed_frame_must_be_latest_argmax(self):
        value = clock(failed=True)
        value["max_wake_frame"] = frame(0, 0.251)
        with self.assertRaisesRegex(AssertionError, "failed argmax"):
            audit.source_clock(value, completed=False, source_late=True)

    def test_yield_cannot_precede_same_frame_maximum_wake(self):
        value = clock()
        value["max_yield_resume_interval"].update(
            yield_elapsed_seconds=0.023, resume_elapsed_seconds=0.024
        )
        with self.assertRaisesRegex(AssertionError, "before maximum wake"):
            audit.source_clock(value, completed=False)


class PrefixTests(unittest.TestCase):
    def setUp(self):
        self.seed = b"\x12\x34" * 1000
        self.clock = clock(failed=True)
        self.prefix = {
            "offered_samples": 640,
            "offered_sha256": audit.sha(self.seed[:1280]),
            "native_accepted_samples": 640,
        }

    def validate(self, value, **kwargs):
        return audit.failure_prefix(
            value, self.clock, self.seed, source_late=True, **kwargs
        )

    def test_prefix_hash_and_native_acceptance_are_separate(self):
        self.validate(self.prefix, committed_samples=320)
        for key, invalid in (
            ("offered_sha256", "0" * 64),
            ("offered_samples", 320),
            ("native_accepted_samples", 641),
            ("native_accepted_samples", True),
            ("native_accepted_samples", None),
            ("native_accepted_samples", 320),
        ):
            with self.subTest(key=key, invalid=invalid):
                with self.assertRaises(AssertionError):
                    self.validate({**self.prefix, key: invalid})

    def test_committed_cannot_exceed_accepted(self):
        with self.assertRaisesRegex(AssertionError, "accepted prefix bound"):
            self.validate(self.prefix, committed_samples=960)

    def test_non_source_late_can_report_missing_native_counter_honestly(self):
        value = {**self.prefix, "native_accepted_samples": None}
        audit.failure_prefix(value, self.clock, self.seed, source_late=False)
        value["accepted_count_error_type"] = "RuntimeError"
        audit.failure_prefix(value, self.clock, self.seed, source_late=False)
        with self.assertRaises(AssertionError):
            self.validate(value)

    def test_terminal_prefix_mismatch_fails(self):
        terminal = {"source_clock": self.clock, "metrics": {"accepted_samples": 320}}
        with self.assertRaisesRegex(AssertionError, "terminal prefix parity"):
            self.validate(self.prefix, terminal=terminal)


class OperationTests(unittest.TestCase):
    def test_shared_origin_reports_overlap_not_causality(self):
        result = audit.operation_clock(operation(), clock(), elapsed_limit=0.05)
        self.assertAlmostEqual(result["argmax_overlap_seconds"]["max_wake"], 0.004)
        self.assertAlmostEqual(
            result["argmax_overlap_seconds"]["max_yield_resume"], 0.001
        )
        self.assertTrue(result["overlap_does_not_establish_causality"])

    def test_interval_and_origin_mutations_fail(self):
        for key, invalid in (
            ("clock", "wall"),
            ("start_monotonic_seconds", 99),
            ("end_monotonic_seconds", 100.0),
            ("wall_ns", 9_000_000),
            ("wall_ns", True),
            ("start_monotonic_seconds", float("inf")),
        ):
            with self.subTest(key=key):
                with self.assertRaises(AssertionError):
                    audit.operation_clock({**operation(), key: invalid}, clock())
        with self.assertRaises(AssertionError):
            audit.operation_clock(operation(), clock(), elapsed_limit=0.026)


class LowLatencyProfileTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(audit.ROOT / "src"))
        from whisper_runtime.profiles import get_profile

        cls.standard = asdict(get_profile("conservative-v1"))
        cls.selected = asdict(get_profile("low-latency-v1"))
        cls.inventory = {
            audit.REUSE_PATCH,
            str(Path(audit.REUSE_PATCH).parent / "SHA256SUMS").replace("\\", "/"),
        }

    def validate(self, plan=None, selected=None, inventory=None):
        return audit.profile_contract(
            plan or {"profile": self.selected, "max_first_commit_seconds": 8},
            self.standard,
            selected or self.selected,
            inventory=self.inventory if inventory is None else inventory,
            frozen=audit.ROOT,
        )

    def test_exact_catalog_and_patch_pair_are_required(self):
        self.assertEqual(self.validate(), 8)
        for name in self.inventory:
            with (
                self.subTest(missing=name),
                self.assertRaisesRegex(AssertionError, "both be uploaded"),
            ):
                self.validate(inventory=self.inventory - {name})

    def test_both_profiles_have_exact_holdback_and_publication_identity(self):
        from whisper_runtime.profiles import get_profile

        for name, contract in audit.LOW_LATENCY_PROFILES.items():
            selected = asdict(get_profile(name))
            registration = {"profile": selected, "max_first_commit_seconds": 8}
            self.assertEqual(self.validate(registration, selected), 8)
            metadata = {
                "execution_profile": selected,
                "stream_config": selected["stream_config"],
                "native_profile_id": selected["native_profile_id"],
                "reuse_alignment_features": True,
                "backend_tree": audit.REUSE_TREE,
                "backend_revision": "1" * 40,
                "profile_id": contract["publication"],
            }
            self.assertEqual(audit.profile_metadata(metadata, selected), "1" * 40)
            for field, value in (
                ("profile_id", "unknown"),
                ("reuse_alignment_features", False),
            ):
                with (
                    self.subTest(name=name, field=field),
                    self.assertRaises(AssertionError),
                ):
                    audit.profile_metadata({**metadata, field: value}, selected)
            for value in (0, 2000, None, True):
                if type(value) is int and value == contract["previous_holdback_ms"]:
                    continue
                changed = copy.deepcopy(selected)
                changed["stream_config"]["previous_holdback_ms"] = value
                with (
                    self.subTest(name=name, holdback=value),
                    self.assertRaises(AssertionError),
                ):
                    self.validate(
                        {"profile": changed, "max_first_commit_seconds": 8}, changed
                    )

    def test_historical_missing_field_defaults_zero_without_rewriting_raw(self):
        from whisper_runtime.profiles import get_profile

        for name, contract in audit.LOW_LATENCY_PROFILES.items():
            selected = asdict(get_profile(name))
            del selected["stream_config"]["previous_holdback_ms"]
            registration = {"profile": selected, "max_first_commit_seconds": 8}
            original = copy.deepcopy(registration)
            if contract["previous_holdback_ms"] == 0:
                self.assertEqual(self.validate(registration, selected), 8)
            else:
                with self.assertRaisesRegex(AssertionError, "exact low-latency"):
                    self.validate(registration, selected)
            self.assertEqual(registration, original)

    def test_no_other_profile_or_relaxed_latency(self):
        for limit in (None, 7, math.nextafter(8.0, math.inf), True, float("inf")):
            with self.subTest(limit=limit), self.assertRaises(AssertionError):
                self.validate(
                    {"profile": self.selected, "max_first_commit_seconds": limit}
                )
        unknown = {**self.selected, "name": "experimental-optimized-v1"}
        with self.assertRaisesRegex(AssertionError, "unregistered audit profile"):
            self.validate({"profile": unknown, "max_first_commit_seconds": 8}, unknown)

    def test_frozen_catalog_cannot_redefine_known_low_latency_settings(self):
        for key, value in (
            ("left_context_ms", 6000),
            ("word_context_limit_ms", 6000),
            ("defer_word_commits", True),
            ("max_draft_tokens", 32),
        ):
            selected = copy.deepcopy(self.selected)
            selected["stream_config"][key] = value
            with (
                self.subTest(key=key),
                self.assertRaisesRegex(AssertionError, "exact low-latency"),
            ):
                self.validate(
                    {"profile": selected, "max_first_commit_seconds": 8}, selected
                )
        selected = {**self.selected, "reuse_alignment_features": False}
        with self.assertRaises(AssertionError):
            self.validate(
                {"profile": selected, "max_first_commit_seconds": 8}, selected
            )

    def test_patch_or_backend_pin_tampering_is_refused(self):
        original = audit.read
        for target in (audit.REUSE_PATCH, "src/whisper_runtime/native_setup.py"):

            def changed(path, *args):
                data = original(path, *args)
                if path == audit.ROOT / target:
                    return (
                        data + b"changed"
                        if target == audit.REUSE_PATCH
                        else data.replace(audit.REUSE_TREE.encode(), b"0" * 40)
                    )
                return data

            with self.subTest(target=target), patch.object(audit, "read", changed):
                with self.assertRaises(AssertionError):
                    self.validate()

    def test_exact_metadata_and_reused_revision(self):
        metadata = {
            "execution_profile": self.selected,
            "stream_config": self.selected["stream_config"],
            "native_profile_id": self.selected["native_profile_id"],
            "reuse_alignment_features": True,
            "backend_tree": audit.REUSE_TREE,
            "backend_revision": "1" * 40,
            "profile_id": audit.LOW_LATENCY_PUBLICATION,
        }
        self.assertEqual(audit.profile_metadata(metadata, self.selected), "1" * 40)
        for key, invalid in (
            ("execution_profile", self.standard),
            ("reuse_alignment_features", False),
            ("native_profile_id", "tiny.en/cli-fp32-v1"),
            ("backend_tree", "0" * 40),
            ("backend_revision", "unknown"),
            ("profile_id", audit.LOW_LATENCY_PUBLICATION + "+verified_draft32/v1"),
        ):
            with self.subTest(key=key), self.assertRaises(AssertionError):
                audit.profile_metadata({**metadata, key: invalid}, self.selected)
        with self.assertRaisesRegex(AssertionError, "revision identity"):
            audit.profile_metadata(metadata, self.selected, previous_revision="2" * 40)


class CommitClockTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(audit.ROOT / "src"))
        from whisper_runtime.adapters import StreamEventKind, TranscriptEvent
        from whisper_runtime.captions import CommittedTranscript

        cls.kind, cls.event, cls.projection = (
            StreamEventKind,
            TranscriptEvent,
            CommittedTranscript,
        )

    def projected(self, *, first_text="first", commit_at=8.0):
        projection = self.projection()
        clock = audit.CommitClock(required=True)
        for number, (kind, elapsed, text) in enumerate(
            (
                ("provisional", 2.1, first_text),
                ("commit", commit_at, None),
            ),
            1,
        ):
            event = {
                "sequence_number": number,
                "kind": self.kind(kind),
                "segment_id": "one",
                "revision": 1,
                "session_version": 1,
                "start_sample": 0,
                "end_sample": 32000,
                "sample_rate_hz": 16000,
                "text": text,
                **(
                    {"committed_through_sample": 32000, "committed_through_ms": 2000}
                    if kind == "commit"
                    else {}
                ),
            }
            caption = projection.accept(self.event(**event))
            clock.accept({"event": event, "elapsed_seconds": elapsed}, caption)
        return clock

    def test_real_projection_counts_commit_with_null_raw_text(self):
        clock = self.projected()
        receipt = clock.verify(
            {"elapsed_seconds": 9.0, "first_commit_seconds": 8.0}, limit=8
        )
        self.assertEqual(receipt["first_nonempty_commit_event_sequence"], 2)
        self.assertEqual(receipt["first_nonempty_commit_source_end_sample"], 32000)

    def test_exact_eight_passes_next_float_fails_without_epsilon(self):
        late = math.nextafter(8.0, math.inf)
        with self.assertRaisesRegex(AssertionError, "exceeded eight seconds"):
            self.projected(commit_at=late).verify(
                {"elapsed_seconds": 9.0, "first_commit_seconds": late}, limit=8
            )

    def test_whitespace_caption_is_not_first_nonempty_commit(self):
        clock = self.projected(first_text=" \n ")
        self.assertIsNone(clock.first)
        with self.assertRaisesRegex(AssertionError, "exceeded eight seconds"):
            clock.verify(
                {"elapsed_seconds": 9.0, "first_commit_seconds": None}, limit=8
            )

    def test_missing_nonfinite_decreasing_or_impossible_event_clock_fails(self):
        for value in (None, True, float("nan"), -1.0, 1.999999999):
            clock = audit.CommitClock(required=True)
            item = {"event": {"end_sample": 32000}}
            if value is not None:
                item["elapsed_seconds"] = value
            with self.subTest(value=value), self.assertRaises(AssertionError):
                clock.accept(item, None)
        clock = self.projected()
        with self.assertRaisesRegex(AssertionError, "nonmonotonic"):
            clock.accept({"event": {}, "elapsed_seconds": 7.999}, None)

    def test_summary_lie_or_terminal_before_event_fails(self):
        clock = self.projected()
        for terminal in (
            {"elapsed_seconds": 9.0, "first_commit_seconds": 7.99},
            {"elapsed_seconds": 7.99, "first_commit_seconds": 8.0},
            {"elapsed_seconds": 9.0},
        ):
            with self.subTest(terminal=terminal), self.assertRaises(AssertionError):
                clock.verify(terminal, limit=8)


class AlignmentInitializationTests(unittest.TestCase):
    def receipt(self):
        return {
            "id": "cuda-backtrace-init-v1",
            "signatures": ["int32[:,::1]", "int32[:,:]"],
            "wall_seconds": 1.25,
            "model_decodes": 0,
            "triton_kernels_warmed": False,
        }

    def test_exact_readiness_is_required_only_for_new_frozen_source(self):
        self.assertIsNone(audit.alignment_initialization({}, required=False))
        with self.assertRaisesRegex(AssertionError, "required alignment"):
            audit.alignment_initialization({}, required=True)
        receipt = self.receipt()
        original = copy.deepcopy(receipt)
        self.assertEqual(
            audit.alignment_initialization(
                {"alignment_initialization": receipt}, required=True, previous=receipt
            ),
            receipt,
        )
        self.assertEqual(receipt, original)
        with self.assertRaisesRegex(AssertionError, "receipt changed"):
            audit.alignment_initialization(
                {"alignment_initialization": receipt},
                required=True,
                previous={**receipt, "wall_seconds": 1.5},
            )

    def test_bad_signatures_model_work_duration_or_unknown_receipt_is_refused(self):
        for key, value in (
            ("id", "unknown"),
            ("signatures", ["int32[:,::1]"]),
            ("signatures", ["int64[:,::1]", "int64[:,:]"]),
            ("model_decodes", False),
            ("model_decodes", 1),
            ("triton_kernels_warmed", True),
            ("triton_kernels_warmed", 0),
            ("wall_seconds", -1),
            ("wall_seconds", True),
            ("wall_seconds", float("nan")),
            ("wall_seconds", float("inf")),
            ("extra", 0),
        ):
            with self.subTest(key=key, value=value), self.assertRaises(AssertionError):
                audit.alignment_initialization(
                    {"alignment_initialization": {**self.receipt(), key: value}},
                    required=True,
                )

    def test_frozen_definition_detects_legacy_and_new_compile_only_contract(self):
        base = audit.ROOT / "artifacts/modal-memory-diagnostic"
        old = base / "two-observation-clock-20260907/source"
        new = base / "backtrace-ready-clock-20260907/source"
        self.assertFalse(audit.alignment_definition(old))
        self.assertTrue(audit.alignment_definition(new))
        original = audit.read

        def changed(path):
            raw = original(path)
            if path == new / "src/whisper_runtime/native_setup.py":
                return raw.replace(b"numba.types.int32, 2", b"numba.types.int64, 2")
            return raw

        with (
            patch.object(audit, "read", changed),
            self.assertRaisesRegex(AssertionError, "compile-only"),
        ):
            audit.alignment_definition(new)


class PostCleanupTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path = (
            audit.ROOT
            / "artifacts/modal-memory-diagnostic/two-observation-clock-20260907/diagnostic.json"
        )
        cls.result = audit.parse(audit.read(path))
        cls.terminal = cls.result["terminal"]
        cls.profile = cls.result["specification"]["input"]["profile"]
        cls.sample = next(
            row["sample"]
            for row in cls.result["snapshots"]
            if row["phase"] == "failure_closed_gc"
        )

    def verify(self, terminal):
        return audit.failure_cleanup_metadata(
            terminal,
            self.profile,
            source_digest=self.terminal["source_digest"],
            instance=self.terminal["instance_id"],
            session_number=1,
            closed_sample=self.sample,
        )

    def test_cleanup_preserves_failure_and_no_pre_gate_terminal(self):
        original = copy.deepcopy(self.terminal)
        report = self.verify(self.terminal)
        self.assertTrue(report["metadata_verified"])
        self.assertTrue(report["does_not_establish_final_or_full_coverage"])
        self.assertEqual(self.terminal, original)
        self.assertEqual(self.terminal["status"], "failed")
        self.assertEqual(self.terminal["error_code"], "source_late")
        self.assertIsNone(self.terminal["terminal_before_gate"])

    def test_missing_legacy_metadata_and_explicit_failed_finalizer_are_distinct(self):
        legacy = copy.deepcopy(self.terminal)
        del legacy["terminal_after_cleanup"]
        self.assertIsNone(self.verify(legacy))
        failed = {**legacy, "terminal_after_cleanup": None, "cleanup_verified": False}
        self.assertIsNone(self.verify(failed))
        with self.assertRaises(AssertionError):
            self.verify({**failed, "cleanup_verified": True})

    def test_bad_cleanup_identity_profile_cuda_or_trace_is_refused(self):
        for key, value in (
            ("source_digest", "changed"),
            ("instance_id", "changed"),
            ("model_final_sha256", "changed"),
            ("model_loads", 2),
            ("capacity_restored", False),
            ("session_number", 2),
            ("allocated_after_bytes", 0),
            ("peak_buffered_samples", 640001),
            ("native_profile_id", "tiny.en/cli-low-latency-fp32-v1"),
            ("last_trace_sha256", "0" * 64),
        ):
            changed = copy.deepcopy(self.terminal)
            changed["terminal_after_cleanup"][key] = value
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.verify(changed)
        for key, value in (("cleanup_verified", False), ("status", "completed")):
            with self.subTest(key=key), self.assertRaises(AssertionError):
                self.verify({**self.terminal, key: value})


class HistoricalTests(unittest.TestCase):
    def test_historical_pass_and_failure_remain_distinct(self):
        for name, expected_exit, expected_status, version in (
            ("capacity-clock-4g-20260907", 0, "passed", "source-clock-v1"),
            ("capacity-smoke-4g-20260907", 1, "failed-run-inspected", None),
            ("verified-startup-clock-20260907", 0, "passed", "source-clock-v2"),
            (
                "low-latency-clock-20260907",
                1,
                "failed-run-inspected",
                "source-clock-v2",
            ),
            (
                "two-observation-clock-20260907",
                1,
                "failed-run-inspected",
                "source-clock-v2",
            ),
            (
                "backtrace-ready-clock-20260907",
                0,
                "passed",
                "source-clock-v2",
            ),
        ):
            with self.subTest(name=name):
                result = subprocess.run(
                    [
                        sys.executable,
                        "-B",
                        str(HERE / "audit_capacity.py"),
                        "--directory",
                        str(audit.ROOT / "artifacts/modal-memory-diagnostic" / name),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                self.assertEqual(
                    result.returncode, expected_exit, result.stdout + result.stderr
                )
                report = json.loads(result.stdout)
                self.assertEqual(report["audit_status"], expected_status, report)
                self.assertEqual(report["source_clock_version"], version)
                self.assertFalse(report["release_qualified"])
                if name == "backtrace-ready-clock-20260907":
                    self.assertTrue(report["capacity_smoke_passed"])
                    self.assertTrue(report["alignment_initialization_required"])
                    self.assertEqual(
                        report["alignment_initialization"]["model_decodes"], 0
                    )
                    self.assertFalse(
                        report["alignment_initialization"]["triton_kernels_warmed"]
                    )
                    self.assertEqual(len(report["sessions"]), 2)
                    for session in report["sessions"]:
                        self.assertEqual(session["samples"], 744800)
                        self.assertEqual(session["events"]["final"], 1)
                        self.assertLessEqual(
                            session["first_nonempty_commit_seconds"], 8
                        )
                if name == "two-observation-clock-20260907":
                    self.assertEqual(report["failure_code"], "source_late")
                    self.assertFalse(report["capacity_smoke_passed"])
                    coverage = report["failed_session_coverage"]
                    self.assertEqual(coverage["native_accepted_samples"], 97920)
                    self.assertEqual(coverage["committed_samples"], 0)
                    self.assertEqual(coverage["events"], {})
                    self.assertTrue(coverage["native_terminal_metadata_available"])
                    self.assertTrue(
                        report["failed_session_cleanup_metadata"]["metadata_verified"]
                    )
                    self.assertIsNone(
                        report["failed_session_commit_clock"][
                            "first_nonempty_commit_seconds"
                        ]
                    )
                if name == "low-latency-clock-20260907":
                    self.assertFalse(report["capacity_smoke_passed"])
                    self.assertEqual(
                        report["failed_session_commit_clock"][
                            "first_nonempty_commit_seconds"
                        ],
                        7.745956607,
                    )
                    coverage = report["failed_session_coverage"]
                    self.assertEqual(coverage["native_accepted_samples"], 744800)
                    self.assertEqual(coverage["committed_samples"], 609600)
                    self.assertEqual(
                        coverage["accepted_but_uncommitted_samples"], 135200
                    )
                    self.assertFalse(coverage["final_received"])
                    self.assertFalse(coverage["native_terminal_metadata_available"])

    def test_frozen_v2_schema_and_resource_gate_detected(self):
        frozen = (
            audit.ROOT
            / "artifacts/modal-memory-diagnostic/verified-startup-clock-20260907/source"
        )
        self.assertEqual(audit.resource_definition(frozen), "source-clock-v2")


if __name__ == "__main__":
    unittest.main()
